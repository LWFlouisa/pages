#################################################################################################################
#                                               Rlyeh Expedition                                                #
#################################################################################################################
def write_stat(stat_file, stat_value)
  File.open("#{stat_file}", "w") { |f|
    f.puts stat_value
  }
end

def monster_counter(beastiary, monster_counter)
  File.open("#{beastiary}", "w") { |f|
    f.puts monster_counter
  }
end

def init_stats
  player_hp       = 10; write_stat("data/player/player_stats/player_hp.txt",                    player_hp)
  shoe_durability = 10; write_stat("data/player/player_stats/player_shoe_durability.txt", shoe_durability)
  antidotes       = 10; write_stat("data/player/player_stats/player_antidotes.txt",             antidotes)
  emergency_ax    = 10; write_stat("data/player/player_stats/player_emergency_ax.txt",       emergency_ax)

  # Is the player poisoned?
  #player_poison = false
    
  # It is presently unknown whether water is acidic.
  #water_acidic  = false
  
  # Does the player have a boat that can resist acid lakes?
  player_boat   = 0
  
  # Available monsters for grinding
  sea_gargoyal = 150; monster_counter("data/beastiary/sea_gargoyal_count.txt", sea_gargoyal)
  acid_dragon  = 150; monster_counter("data/beastiary/acid_dragon_count.txt",   acid_dragon)
  acid_serpent = 150; monster_counter("data/beastiary/acid_serpent_count.txt", acid_serpent)
end

define_method mettre_de_sabots(a, b, c),     "#{a} slips on special clogs to walk from #{b} to #{c}."
define_method porte_de_sabots(a, b, c),      "#{a} walks in the clogs to walk from #{b} to #{c}."
define_method dommage_de_koke(a, player_hp), "The #{a} currently has ##{player_hp} life points left."
define_method poison_koke(a, b),             "The poison moss spread from tile #{a} to tile #{b}."

#def est_empoisonne(player_name, player_poison, antiodate)
#  if player_poison == true
#    player_hp = player_hp - 5
#
#    puts "#{player_name} has lost five hit points."
#
#    File.open("data/player/player_stats/player_hp.txt", "w") { |f|
#      f.puts player_hp
#    }
#  elsif player_poison == true && antidote >= 0
#    antiodate = antidote - 1
#    
#    puts "#{player_name} has been cleared of poison."
#
#    File.open("data/player/player_inventory/antidote.txt", "w") { |f|
#      f.puts antiodate
#    }
#  else
#    puts "#{player_name} has not been poisoned."
#  end
#end

#def east_eau_de_acide(current_location)
#end

#def avoir_un_bateau(a)
#  if player_boat == true && water_acidic == false
#    "#{a} has a boat, but is the water acidic?"
  
#    est_eau_de_acide(cthulhu_temple)
#  elsif $player_boat == false and $water_acidic == true
#    est_eau_de_acide(cthulhu_temple)
    
#    "You need to find a boat that can resist the PH value of dead restless spirits."
#  elsif $player_boat == true and $water_acidic == true
#    "#{a} has a boat that can be rowed across #{b}."
#  else
#    "#{a} has no boat doesn't know if water is acidic."
#  end
#end

#define_method :est_monstre_proche do |a, b, c|
#  if $sea_gargoyal > 0
#    "The sea gargoyals of #{a} are nearby."
#    
#    fight_snakes?(a)
#  end
#  
#  if $acid_dragon > 0
#    "The acid dragons of #{b} are nearby."
#    
#    fight_dragons?(b)
#  end
#  
#  if $acid_serpent > 0
#    "The acid snakes of #{c} are nearby."
#    
#    fight_serpents?(c)
#  end
#end

#define_method :est_porte_fermee do
#  if    $door_locked == true and $emergency_ax == false
#    "Is the door locked? Yes, go find an emergency ax."
#  elsif $door_locked == true and $emergency_ax == true
#    "Is the door locked? You used the emergency ax."

#    $emergency_ax = $emergency_ax - 1
#  elsif $door_locked == false and $emergency_ax == false
#    "Is the door locked? But its still advised to find an emergency ax."
#  elsif $door_locked == false and $emergency_ax == true
#    "Is the door locked? No, but save the ax for fighting monsters."
#  else
#  end
#end
