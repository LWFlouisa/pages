module Lhacurimosa
  VERSION = "0.2.8"

  ######################################################################################
  #                      Negative And Positive Constraint Logic                        #
  ######################################################################################
  # Rather than saying what room your in exactly, the idea is a way to describe what   #
  # is or isn't in a room in order to infer what room you might be in based on the     #
  # the subtext of what things are left behind.                                        #
  ######################################################################################
  class LispTranspile
    def self.nem(x, y, z)
      File.open("lisp/ne_mais.lisp", "w") { |f|
        heredoc = <<-GENERATED_CODE
        (defun ne (x y)
          (princ "Non ")
  
          (format t "~a" x)
  
          (princ " ou ")
  
          (format t "~a" y)
        )

        (defun mais (z)
          (princ ", mais c'est ")
  
          (format t "~a" z)

          (princ ".")
        )

        (defun ne_mais (a b)
          (progn (format nil "~a" a) (format nil "~a" b))
        )
  
        (ne_mais (ne "#{x}" "#{y}") (mais "#{z}"))
        GENERATED_CODE
  
        f.puts heredoc
      }
    end
    
    def self.ouinon(x, y, z)
      File.open("lisp/ouinon.lisp", "w") { |f|
        heredoc = <<-OUINON
        (defun oui (x y)
          (princ "Oui, ")  
  
          (format t "~a" x)
  
          (princ " et ")
  
          (format t "~a" y)
        )
  
        (defun et_non (z)
          (princ ", et non")
  
          (format t "~a" x)
  
          (princ ".")
        )
  
        (def ouinon (x y z)
          (progn (oui (format nil "~a" x) (format nil "~a" y)) (et_non (format nil "~a" z)))
        )
  
        (ouinon (oui "#{x}" "#{y}") (et_non "#{z}"))
        OUINON

        f.puts heredoc
      }
    end
    
    def self.sore(x_probability, x_greater_than,    x_less_than,
                  y_probability, y_greater_than,    y_less_than,
                  z_probability,  z_maybe_state,  z_above_below)
      
      File.open("lisp/sore.lisp", "w") { |f|
        heredoc = <<-SORE
        #| Positive Probabilistic Otherwise |#
        (defun sore (current_percentile greater_than less_than)
          (setq x current_percentile) (if (> x 0.8) (format nil "~a" greater_than) (format nil "~a" less_than))
        )

        (defun shikashi (current_percentile greater_than less_than)
          (setq x current_percentile) (if (< x 0.2) (format nil "~a" greater_than) (format nil "~a" less_than))
        )

        (defun matawa (current_percentile maybe_state above_below )
          (setq x 0.8)
          (setq y 0.2)

          (setq z current_percentile)

          (if (and (< z x) (> z y)) (format nil "~a" maybe_state) (format nil "~a" above_below))
        )
  
        sore(#{x_probability}     #{x_greater_than}    #{x_less_than})
        shikashi(#{y_probability} #{y_greater_than}    #{z_less_than})
        matawa(#{z_probability}   #{z_maybe_state}   #{z_above_below})
        SORE
  
        f.puts heredoc
      }
    end
    
    def self.nisore(x_probability, x_greater_than,   x_less_than,
                    y_probability, y_greater_than,   y_less_than,
                    z_probability, z_maybe_state,  z_above_below)
                    
      File.open("lisp/nisore.lisp", "w") { |f|
        heredoc = <<-SORE
        #| Negative Probabilistic Otherwise |#
        (defun nisore (current_percentile greater_than less_than)
          (setq x current_percentile) (if (< x 0.8) (format nil "~a" greater_than) (format nil "~a" less_than))
        )

        (defun nishikashi (current_percentile greater_than less_than)
          (setq x current_percentile) (if (> x 0.2) (format nil "~a" greater_than) (format nil "~a" less_than))
        )

        ; This determines whether something is below meaningful measurement or above it.
        (defun nimatawa (current_percentile maybe_state above_below )
          (setq x 0.8)
          (setq y 0.2)

          (setq z current_percentile)

          (if (and (< z x) (> z y)) (format nil "~a" above_below) (format nil "~a" maybe_state))
        )
  
        nisore(#{x_probability}     #{x_greater_than}    #{x_less_than})
        nishikashi(#{y_probability} #{y_greater_than}    #{z_less_than})
        nimatawa(#{z_probability}   #{z_maybe_state}   #{z_above_below})
        SORE
  
        f.puts heredoc
      }
    end
  end
  
  class AncientKnowledge
    #######################################################################################
    #                                    Awasunu III                                      #
    #######################################################################################
    # This measures the ages of ancient ruins and people whom travel them, in order to    #
    # build a larger world dossier.                                                       #
    #######################################################################################
    def self.obelisk(old_data)
      old_graveyard = File.readlines("graveyard/urn.txt").shuffle
      size_limit    = old_graveyard.size.to_i
      index = 0

      File.open("memoricimetiere/urn.txt", "w") { |f|
        f.puts old_data
      
        size_limit.times do
          f.puts old_graveyard[index]
 
          index = index + 1
        end
      }
    end

    def self.yonagumi(current_year, specific_event)
      age_of_yonagumi = 11000.0
  
      age_percent = age_of_yonagumi - current_year
  
      " For a point of comparison: Yonagumi is #{age_percent} years old as of #{current_year}."

      obelisk("For a point of comparison: Yonagumi is #{age_percent} years old as of #{current_year}.")
      scatter_ashes
    end

    def age_comparison(current_year, age_historical, specific_event)
      years_ago = current_year - age_historical
  
      print "The current year is #{current_year}, #{specific_event} is #{years_ago} years ago."
      puts yonagumi(2026.0, "#{specific_event}")
      
      obelisk("The current year is #{current_year}, #{specific_event} is #{years_ago} years ago.")
    end

    #def self.ternary(x, upper_boundary, lower_boundary, upper_maybe, lower_maybe)
    #  sore_kosan = Proc(Float64, Float64, String).new { | x, upper_boundary |
    #    x > interval ? %Q(#{bot_name}: #{x} has reached the upper limit in growth.) : %Q(#{bot_name}: #{x} has reached the upper limit in growth.)
    #  }

    #  shikashi_kosan = Proc(Float64, Float64, String).new { | x, lower_boundary |
    #    x > interval ? %Q(#{bot_name}: #{x} has reached the upper limit in growth.) : %Q(#{bot_name}: #{x} has reached the upper limit in growth.)
    #  }

    #  matawa_kosan = Proc(Float64, Float64, Float64, String).new { | x, first_interval, second_interval |
    #    x > first_interval && x < second_interval ? %Q(#{bot_name}: #{x} is floating between growth intervals #{first_interval} and #{second_interval}.) : %Q(#{bot_name}: #{x} is not floating between growth intervals #{first_interval} and #{second_interval}.)
    #  }
  
      ## Boundary conditions
    #  sore_kosan.call(x, upper_boundary)
    #  shikashi_kosan.call(x, lower_boundary)
  
      ## Maybe State
    #  matawa_kosan.call(x, upper_maybe, lower_maybe)
    #end
  end
end

# module LhacurimosaSpatialPerimeters
#   VERSION = "0.2.8"

#   class Static_Perimeters

    # The objects within the space.
#     def self.positive_perimeters
      # Base radius of static objects.
#       base_radius   = 2500
    
      # Specfic multipliers for Earth index based objects.
#       base_two =  2   
#       base_fro =  4
#       base_six =  6
#       base_eit =  8
  
      # Size of specific objects.
#       size_of_planets    = base_radius ** base_fro
#       size_of_moons      = base_radius ** base_two
#       size_of_stars      = base_radius ** base_six
#       size_of_blackholes = base_radius ** base_eit
    
      # Total output sizes of specific objects.
#       puts "The size of the planets is #{size_of_planets} radius."; sleep(3)
#       puts "The size of the moons is #{size_of_moons} radius."; sleep(3)
#       puts "The size of the stars is #{size_of_stars} radius."; sleep(3)
#       puts "The size of a blackhole is #{size_of_blackholes} radius."; sleep(3)
#     end
  
    # Space between the objects.
#     def self.negative_perimeters
      # Base distance between objects.
#       base_distance = 1_000_000_000
  
      # Estimated divider between specific objects to base distance.
#       space_between_planets    = 43.8
#      space_between_moons      = 14.6
#      space_between_stars      = 876
#      space_between_blackholes = 2628
    
      # Minimum distance between objects.
#      planet_distance    = base_distance / space_between_planets
#      moon_distance      = base_distance / space_between_moons
#      star_distance      = base_distance / space_between_stars
#      blackhole_distance = base_distance / space_between_blackholes
    
      # Actual distance between objects
#      actual_planets    = planet_distance * 10
#      actual_moons      = moon_distance * 10
#      actual_stars      = star_distance * 10
#      actual_blackholes = blackhole_distance * 10
    
      # The output results of distance between objects.
#      puts "The distance between planets is #{actual_planets} miles."; sleep(3)
#      puts "The distance between moons is #{actual_moons} miles."; sleep(3)
#      puts "The distance between stars is #{actual_stars} miles."; sleep(3)
#      puts "The distance between blackholes is #{actual_blackholes} miles."; sleep(3)
#    end
#  end

  # Changing perimeters
#  class Dynamic_Perimeters
#    # The objects within the space.
#    def self.positive_perimeters
#      spaceship     = File.read("data/dynamic/positive_perimenters/spaceship_size.txt").strip.to_i
#      space_station = spaceship * 200
#      satalite      = space_station / 10
#    
#      puts "The total size of the space shuttle is #{spaceship} feet."; sleep(3)
#      puts "The total size of the space station is #{space_station} feet."; sleep(3)
#      puts "The total size of the satalite is #{satalite} feet."; sleep(3)
#    end
  
    # Space between the objects.
#    def self.negative_perimeters
#      base_multiplier = 10
  
      # Minimum space between objects.
#      space_between_spaceships = File.read("data/dynamic/negative_perimeters/space_between_spaceships.txt").strip.to_i
#      space_between_station    = File.read("data/dynamic/negative_perimeters/space_between_station.txt").strip.to_i
#      space_between_satalite   = File.read("data/dynamic/negative_perimeters/space_between_satalite.txt").strip.to_i
    
#      # Actual space between objects
#      actual_spaceship_distance = space_between_spaceships * base_multiplier
#      actual_station_distance   = space_between_station * base_multiplier
#      actual_satalite_distance  = space_between_satalite * base_multiplier
    
#      puts "The minimum space between shuttles is #{actual_spaceship_distance} feet."; sleep(3)
#      puts "The minimum space between stations is #{actual_station_distance} feet."; sleep(3)
#      puts "The minimum space between satalites is #{actual_satalite_distance} feet."; sleep(3)
#    end
#  end
#end

################################################################################################
#                                  Process Of Elimination                                      #
################################################################################################
def find_candidate
  ## Determining user data and user choice.
  value = File.read("_input/user/user_choice.txt").to_s.to_i

  user_data   = File.readlines("_data/user/candidates.txt")
  user_choice = user_data[value]

  ## Processing AI focused data
  ai_choice            = File.read("_data/ai/ai_choice.txt").to_s.to_i
  ai_initial_candidate = user_data[ai_choice]
  ai_search_limit      = user_data.size.to_i

  ## Create AI data from user data.
  ai_search_limit.times do
    if ai_choice == user_choice
      puts "The specific candidate was found. Terminating selection..."

      ai_data      = user_data.slice!(ai_choice)

      open("_data/ai/candidates.txt", "w") { |f|
        f.puts ai_data
      }
    else
      puts "The specific candidate is not found..."
    end
  end

  ## AI processing data.
  ai_choice            = File.read("_data/ai/ai_choice.txt").to_s.to_i
  ai_data              = File.readlines("_data/ai/candidates.txt")
  ai_search_limit      = ai_data.size.to_i
  ai_next_candidate    = ai_data[ai_choice]

  ai_search_limit.times do
    if ai_next_candidate == user_choice
      ai_final_candidate = ai_next_candidate
    
      puts "Candidate found, processing input..."; sleep(1)

      open("_posts/input.md", "w") { |f|
        f.puts "## #{date_title}"
        f.puts "By process of elimination, the bot chose: #{ai_final_candidate}"
      }
    else
      puts "Candidate is not yet found..."

      ai_choice            = File.read("_data/ai/ai_choice.txt").to_s.to_i
      ai_data              = File.readlines("_data/ai/candidates.txt")
      ai_search_limit      = ai_data.size.to_i
      ai_next_candidate    = ai_data[ai_choice]

      ai_data      = user_data.slice!(ai_choice)

      open("_data/ai/candidates.txt", "w") { |f|
        f.puts ai_data
      }
    end
  end
end

################################################################################################
#                            Selective Decision Tree Revesukyana                               #
################################################################################################
module SpatialRelationships
  class Error < StandardError; end

  class Static_Perimeters

    # The objects within the space.
    def self.positive_perimeters
      # Base radius of static objects.
      base_radius   = 2500
    
      # Specfic multipliers for Earth index based objects.
      base_two =  2   
      base_fro =  4
      base_six =  6
      base_eit =  8
  
      # Size of specific objects.
      size_of_planets    = base_radius ** base_fro
      size_of_moons      = base_radius ** base_two
      size_of_stars      = base_radius ** base_six
      size_of_blackholes = base_radius ** base_eit
    
      # Total output sizes of specific objects.
      puts "The size of the planets is #{size_of_planets} radius."; sleep(3)
      puts "The size of the moons is #{size_of_moons} radius."; sleep(3)
      puts "The size of the stars is #{size_of_stars} radius."; sleep(3)
      puts "The size of a blackhole is #{size_of_blackholes} radius."; sleep(3)
    end
  
    # Space between the objects.
    def self.negative_perimeters
      # Base distance between objects.
      base_distance = 1_000_000_000
  
      # Estimated divider between specific objects to base distance.
      space_between_planets    = 43.8
      space_between_moons      = 14.6
      space_between_stars      = 876
      space_between_blackholes = 2628
    
      # Minimum distance between objects.
      planet_distance    = base_distance / space_between_planets
      moon_distance      = base_distance / space_between_moons
      star_distance      = base_distance / space_between_stars
      blackhole_distance = base_distance / space_between_blackholes
    
      # Actual distance between objects
      actual_planets    = planet_distance * 10
      actual_moons      = moon_distance * 10
      actual_stars      = star_distance * 10
      actual_blackholes = blackhole_distance * 10
    
      # The output results of distance between objects.
      puts "The distance between planets is #{actual_planets} miles."; sleep(3)
      puts "The distance between moons is #{actual_moons} miles."; sleep(3)
      puts "The distance between stars is #{actual_stars} miles."; sleep(3)
      puts "The distance between blackholes is #{actual_blackholes} miles."; sleep(3)
    end
  
  end

  # Changing perimeters
  class Dynamic_Perimeters

    # The objects within the space.
    def self.positive_perimeters
      spaceship     = File.read("data/dynamic/positive_perimenters/spaceship_size.txt").strip.to_i
      space_station = spaceship * 200
      satalite      = space_station / 10
    
      puts "The total size of the space shuttle is #{spaceship} feet."; sleep(3)
      puts "The total size of the space station is #{space_station} feet."; sleep(3)
      puts "The total size of the satalite is #{satalite} feet."; sleep(3)
    end
  
    # Space between the objects.
    def self.negative_perimeters
      base_multiplier = 10
  
      # Minimum space between objects.
      space_between_spaceships = File.read("data/dynamic/negative_perimeters/space_between_spaceships.txt").strip.to_i
      space_between_station    = File.read("data/dynamic/negative_perimeters/space_between_station.txt").strip.to_i
      space_between_satalite   = File.read("data/dynamic/negative_perimeters/space_between_satalite.txt").strip.to_i
    
      # Actual space between objects
      actual_spaceship_distance = space_between_spaceships * base_multiplier
      actual_station_distance   = space_between_station * base_multiplier
      actual_satalite_distance  = space_between_satalite * base_multiplier
    
      puts "The minimum space between shuttles is #{actual_spaceship_distance} feet."; sleep(3)
      puts "The minimum space between stations is #{actual_station_distance} feet."; sleep(3)
      puts "The minimum space between satalites is #{actual_satalite_distance} feet."; sleep(3)
    end

  end
end

def sentrope(small_percentage, large_percentage)
  shannons_entropy = small_percentage / large_percentage

  content = <<-SHANNONS_ENTROPY
  (defun shannons_entropy (entropy_factor)
    (princ "the element of surprise is ")
      
    (format t "~a" entropy_factor)
 
    (princ " percent.")
  )
    
  (livretrude #{a} #{b} #{v} #{n} #{s})
    
  (shannons_entropy #{shannons_entropy})
  SHANNONS_ENTROPY

  puts "The element of surprise is #{shannons_entropy} percent."

  File.open("lisp/shannons_entropy.lisp", "w") { |f|
    f.puts content
  }
end

def maison_iceburg(surface_layer, interior_layer, small_percentage, large_percentage)
  house_percentage = surface_layer / interior_layer

  entropy_calculation = sentrope(small_percentage, large_percentage)

  content = <<-HOUSE_SURFACE
  (defun maison_iceburg (house_percentage, entropy_calculation)
    (princ "The surface of the house is ")
        
    (format t "~a" house_percentage)
        
    (princ " percentage: ")
        
    (format t "~a" entropy_calculation)
  )
  
  (maison_iceburg #{house_percentage} #{entropy_calculation})
  HOUSE_SURFACE
  
  File.open("lisp/maison_iceburg.lisp", "w") { |f|
    f.puts content
  }
end

#def corpus_de_livretrude(object, subject, verb)
#  content = <<-LIVRETRUDE
#  word_orders = [
#    [[verb:     #{verb}, objet:  #{object}, subjet: #{subjet}],
#     [objet:   #{objet}, subjet: #{subjet}, verb:     #{verb}],
#     [subjet: #{subjet}, objet:  #{object}, objet:  #{object}]],

#    [[subjet: #{subjet}, objet:  #{object}, objet:  #{object}],
#     [verb:     #{verb}, objet:  #{object}, subjet: #{subjet}],
#     [objet:   #{objet}, subjet: #{subjet}, verb:     #{verb}]],

#    [[objet:   #{objet}, subjet: #{subjet}, verb:     #{verb}],
#     [subjet: #{subjet}, objet:  #{object}, objet:  #{object}],
#     [verb:     #{verb}, objet:  #{object}, subjet: #{subjet}]],
#  ]
#  LIVRETRUDE

#  File.open("msrc/corpus_de_livretrude.cr", "w") { |f|
#    f.puts content
#  }
#end

def livretude(a, b, v, n, s)
  content = <<-LIVRETUDE
  (defun livretude (a b v n s)
    (princ "[")

    (format t "~a" a)

    (princ ", ")

    (format t "~a" b)
      
    (princ "] | [")
      
    (format t "~a" v)
    (format t "~a" n)
    (format t "~a" s)

    (princ "]")
  )

  (livretrude #{a} #{b} #{v} #{n} #{s})
  LIVRETUDE
  
  File.open("lisp/livretude.lisp", "w") { |f|
    f.puts content
  }
end
