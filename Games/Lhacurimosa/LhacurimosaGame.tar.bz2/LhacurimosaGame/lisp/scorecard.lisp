(require "NeMais")

(defun scorecard (frock fpaper fscissors)
  (setq rock_score         frock)
  (setq paper_score       fpaper)
  (setq scissors_score fscissors)
  
  (princ "
ROCK SCORES
")
  (princ (sore rock_score       "BIANCA: You achieved the maximum rock score."         "BIANCA: You never achieved a maximum rock score."))
  (princ (shikashi rock_score  " You achieved the medicore paper score."       " You never achieved a medicore paper score."))
  (princ (matawa rock_score " You achieved the minimal scissors score." " You never achieved a minimal scissors score."))

  (princ "
PAPER SCORES
")
  (princ (sore paper_score       "BIANCA: You achieved the maximum rock score."         "BIANCA: You never achieved a maximum rock score."))
  (princ (shikashi paper_score  " You achieved the maximum paper score."       " You never achieved a paper score."))
  (princ (matawa paper_score " You achieved the minimal scissors score." " You never achieved a minimal scissors score."))

  (princ "
SCISSORS SCORES
")
  (princ (sore scissors_score       "BIANCA: You achieved the maximum rock score."         "BIANCA: You never achieved a maximum rock score."))
  (princ (shikashi scissors_score  " You achieved the medicore paper score."       " You never achieved a medicore paper score."))
  (princ (matawa scissors_score " You achieved the minimal scissors score." " You never achieved a minimal scissors score."))
)

(scorecard 0.12 0.01 0.07)
