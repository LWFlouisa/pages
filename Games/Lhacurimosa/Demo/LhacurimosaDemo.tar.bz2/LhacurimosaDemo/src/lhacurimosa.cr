###############################################################################
#                 Depricating Soon, Looking For Alternative                   #
###############################################################################
def sore_float(condition)    
  if condition
    if yield && yield.is_a?(Float)
      return true
    else
      return "Error: Sore_float is not a Float."
    end
  end
  
  false
end

def shikashi_float(already_done, condition)
  return true if already_done
  
  if condition
    if yield && yield.is_a?(Float)
      return true
    else
      return "Error: Shikashi_float is not a Float."
    end
  end
end

def matawa_float(already_done)
  value = yield unless already_done

  if value && value.is_a?(Float)
    return true
  else
    return "Error: Shikashi_float is not a Float."
  end
  
  unless already_done
    otherwise = already_done
      
    if defined(otherwise)
      puts otherwise
    end
  else
    puts "Otherwise is not defined."
  end
end

#######################################################################################
#                         Genetic Reinforcement Naive Bayes                           #
#######################################################################################
def get_statistics(a1, a2, b1, b2, c1, c2)
  a = [ a1, a2 ]
  b = [ b1, b2 ]
  c = [ c1, c2 ]

  matrix = [[
    [[a[0], a[0]], [a[0], b[0]], [a[0], c[0]]],
    [[b[0], a[0]], [b[0], b[0]], [b[0], c[0]]],
    [[c[0], a[0]], [c[0], b[0]], [c[0], c[0]]],
  ], [
    [[a[1], a[1]], [a[1], b[1]], [a[1], c[1]]],
    [[b[1], a[1]], [b[1], b[1]], [b[1], c[1]]],
    [[c[1], a[1]], [c[1], b[1]], [c[1], c[1]]],
  ], [
    [[0.50, 0.50], [0.50, 0.50], [0.50, 0.50]],
    [[0.50, 0.50], [0.50, 0.50], [0.50, 0.50]],
    [[0.50, 0.50], [0.50, 0.50], [0.50, 0.50]],
  ]]

  label_type       = matrix[0]
  definition_type  = matrix[1]
  probability_type = matrix[2]
  
  row_probability = 0.33
  col_probability = 0.33
  
  graph_selection = row_probability * col_probability

  row_options = [0, 1, 2]
  col_options = [0, 1, 2]
  arr_options = [0, 1]

  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample
  
  current_label       = label_type[cur_row][cur_col][cur_arr]
  current_definition  = definition_type[cur_row][cur_col][cur_arr]
  
  base_probability = probability_type[cur_row][cur_col][cur_arr].to_i
  
  current_probability = base_probability + graph_selection
  
  current_probability = current_probability + current_probability
  current_information = "#{current_label} #{current_definition}"
  
  puts "I'm confident it is not [ #{current_label} #{current_definition} ] as it has only #{current_probability} probability."
  
  #File.write("data/statistics/probability/current_probability.txt", "#{current_probability}")
  #File.write("data/statistics/label/current_information.txt",       current_information)

  File.write("data/statistics/probability/current_probability.txt", "#{current_probability}")
  File.write("data/statistics/label/current_information.txt",            current_information)
  File.write("data/statistics/description/current_description.txt",      current_description)
  File.write("data/statistics/symbol/current_label.txt",                 current_symbol)
end

def gain
  current_probability = File.read("data/statistics/probability/current_probability.txt").to_f
  current_information = File.read("data/statistics/label/current_information.txt")

  if current_probability > 0.999999999999999999
    current_probability = 0.9 / current_probability
  end
  
  case current_probability
  when 0.003921569000000000..0.287225000000000000
    "I'm confident it is not [ #{current_information} ] as its only #{current_probability}."
  when 0.287225000000000001..0.522225000000000000
    "I'm less unconfident it is not [ #{current_information} ] as its only #{current_probability}."
  when 0.522225000000000001..0.756112500000000000
    "I'm almost sure it is [ #{current_information} ] because it has #{current_probability}."
  when 0.756112500000000001..0.999999999999999999
    "I'm sure it is [ #{current_information} ] after all it has #{current_probability}."

  else
    "The probability is either to low or to large, so I can't determine exactly."
  end
  
  current_probability    = current_probability + 0.15
  
  File.write("data/statistics/probability/current_probability.txt", "#{current_probability}")
  File.write("data/statistics/label/current_information.txt",       current_information)
end

def loss
  current_probability = File.read("data/statistics/probability/current_probability.txt").to_f
  current_information = File.read("data/statistics/label/current_information.txt")

  if current_probability > 0.999999999999999999
    current_probability = 0.9 / current_probability
  end
  
  case current_probability
  when 0.003921569000000000..0.287225000000000000
    "I'm confident it is not [ #{current_information} ] as its only #{current_probability}."
  when 0.287225000000000001..0.522225000000000000
    "I'm less unconfident it is not [ #{current_information} ] as its only #{current_probability}."
  when 0.522225000000000001..0.756112500000000000
    "I'm almost sure it is [ #{current_information} ] because it has #{current_probability}."
  when 0.756112500000000001..0.999999999999999999
    "I'm sure it is [ #{current_information} ] after all it has #{current_probability}."

  else
    "The probability is either to low or to large, so I can't determine exactly."
  end
  
  current_probability    = current_probability * 0.95
  
  File.write("data/statistics/probability/current_probability.txt", "#{current_probability}")
  File.write("data/statistics/label/current_information.txt",       current_information)
end

def dynamic_reward_allocation
  l1_reasses = "level one reasses"
  l2_reasses = "level two reasses"
  l3_reasses = "level tre reasses"
  l4_reasses = "level fro reasses"

  reward_model = [
    [[l1_reasses, l1_reasses, l1_reasses, l1_reasses],
     [l1_reasses, l1_reasses, l1_reasses, l2_reasses],
     [l1_reasses, l1_reasses, l1_reasses, l3_reasses],
     [l1_reasses, l1_reasses, l1_reasses, l4_reasses]],
   
    [[l2_reasses, l2_reasses, l2_reasses, l1_reasses],
     [l2_reasses, l2_reasses, l2_reasses, l2_reasses],
     [l2_reasses, l2_reasses, l2_reasses, l3_reasses],
     [l2_reasses, l2_reasses, l2_reasses, l4_reasses]],
   
    [[l3_reasses, l3_reasses, l3_reasses, l1_reasses],
     [l3_reasses, l3_reasses, l3_reasses, l2_reasses],
     [l3_reasses, l3_reasses, l3_reasses, l3_reasses],
     [l3_reasses, l3_reasses, l3_reasses, l4_reasses]],
   
    [[l4_reasses, l4_reasses, l4_reasses, l1_reasses],
     [l4_reasses, l4_reasses, l4_reasses, l2_reasses],
     [l4_reasses, l4_reasses, l4_reasses, l3_reasses],
     [l4_reasses, l4_reasses, l4_reasses, l4_reasses]],
  ]

  row_options = [0, 1, 2, 3]
  col_options = [0, 1, 2, 3]
  arr_options = [0, 1, 2, 3]

  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample

  current_reward_structure = reward_model[cur_row][cur_col][cur_arr]

  if    current_reward_structure == l1_reasses; gain
  elsif current_reward_structure == l2_reasses; 2.times do gain end
  elsif current_reward_structure == l3_reasses; 3.times do gain end
  elsif current_reward_structure == l4_reasses; 4.times do gain end
  else
    gain
  end
end

def dynamic_guillotine_allocation
  l1_reasses = "level one reasses"
  l2_reasses = "level two reasses"
  l3_reasses = "level tre reasses"
  l4_reasses = "level fro reasses"

  reward_model = [
    [[l1_reasses, l1_reasses, l1_reasses, l1_reasses],
     [l1_reasses, l1_reasses, l1_reasses, l2_reasses],
     [l1_reasses, l1_reasses, l1_reasses, l3_reasses],
     [l1_reasses, l1_reasses, l1_reasses, l4_reasses]],
   
    [[l2_reasses, l2_reasses, l2_reasses, l1_reasses],
     [l2_reasses, l2_reasses, l2_reasses, l2_reasses],
     [l2_reasses, l2_reasses, l2_reasses, l3_reasses],
     [l2_reasses, l2_reasses, l2_reasses, l4_reasses]],
   
    [[l3_reasses, l3_reasses, l3_reasses, l1_reasses],
     [l3_reasses, l3_reasses, l3_reasses, l2_reasses],
     [l3_reasses, l3_reasses, l3_reasses, l3_reasses],
     [l3_reasses, l3_reasses, l3_reasses, l4_reasses]],
   
    [[l4_reasses, l4_reasses, l4_reasses, l1_reasses],
     [l4_reasses, l4_reasses, l4_reasses, l2_reasses],
     [l4_reasses, l4_reasses, l4_reasses, l3_reasses],
     [l4_reasses, l4_reasses, l4_reasses, l4_reasses]],
  ]

  row_options = [0, 1, 2, 3]
  col_options = [0, 1, 2, 3]
  arr_options = [0, 1, 2, 3]

  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample

  current_reward_structure = reward_model[cur_row][cur_col][cur_arr]

  if    current_reward_structure == l1_reasses; loss
  elsif current_reward_structure == l2_reasses; 2.times do loss end
  elsif current_reward_structure == l3_reasses; 3.times do loss end
  elsif current_reward_structure == l4_reasses; 4.times do loss end
  else
    loss
  end
end

def dynamic_mode_switcher
  modes = [
    [["deposit", "deposit"], ["deposit", "extract"]],
    [["extract", "deposit"], ["extract", "extract"]],
  ]
  
  row_options = [0, 1]
  col_options = [0, 1]
  arr_options = [0, 1]

  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample

  current_mode = modes[cur_row][cur_col][cur_arr]

  if    current_mode == "deposit"; dynamic_reward_allocation
  elsif current_mode == "extract"; dynamic_guillotine_allocation
  else
    dynamic_guillotine_allocation
  end
end

def get_edge_cases(a1, a2, b1, b2, c1, c2, d1, d2, e1, e2, f1, f2)
  a = [ a1, a2 ]
  b = [ b1, b2 ]
  c = [ c1, c2 ]
  d = [ d1, d2 ]
  e = [ e1, e2 ]
  f = [ f1, f2 ]

  edges_cases = [[
    [ a[0], e[0], b[0], d[0], f[0], c[0] ],
    [ e[0], b[0], d[0], f[0], c[0], a[0] ],
    [ b[0], d[0], f[0], c[0], a[0], e[0] ],
    [ d[0], f[0], c[0], a[0], e[0], b[0] ],
    [ f[0], c[0], a[0], b[0], d[0], e[0] ],
    [ c[0], a[0], e[0], b[0], d[0], f[0] ],
  ], [
    [ a[1], e[1], b[1], d[1], f[1], c[1] ],
    [ e[1], b[1], d[1], f[1], c[1], a[1] ],
    [ b[1], d[1], f[1], c[1], a[1], e[1] ],
    [ d[1], f[1], c[1], a[1], e[1], b[1] ],
    [ f[1], c[1], a[1], b[1], d[1], e[1] ],
    [ c[1], a[1], e[1], b[1], d[1], f[1] ],
  ]]
  
  symbols      = edges_cases[0]
  descriptions = edges_cases[1]

  row_options = [0, 1, 2, 3, 4, 5]
  col_options = [0, 1, 2, 3, 4, 5]
  
  cur_row = row_options.sample
  cur_col = col_options.sample
  
  first_symbol      = symbols[cur_row][cur_col] #[cur_arr]
  first_description = descriptions[cur_row][cur_col] #[cur_arr]

  cur_row = row_options.sample
  cur_col = col_options.sample
  #cur_arr = arr_options.sample
  
  second_symbol      = symbols[cur_row][cur_col] #[cur_arr]
  second_description = descriptions[cur_row][cur_col] #[cur_arr]

  cur_row = row_options.sample
  cur_col = col_options.sample
  #cur_arr = arr_options.sample
  
  third_symbol      = symbols[cur_row][cur_col] #[cur_arr]
  third_description = descriptions[cur_row][cur_col] #[cur_arr]
  
  2.times do
    get_statistics(first_symbol,  first_description,
                   second_symbol, second_description,
                   third_symbol,  third_description)
                   
                   dynamic_reward_allocation
  end
end

def hyper_statistics(a1, a2, b1, b2, c1, c2)
  a = [ a1, a2 ]
  b = [ b1, b2 ]
  c = [ c1, c2 ]
  
  d = convert_to_piano_to_percent(generate_bounded_probability)

  matrix = [[
    [[[a[0], c[0]],
      [a[0], a[0]],
      [a[0], a[0]]],
     
     [[a[0], b[0]],
      [a[0], a[0]],
      [b[0], a[0]]],

     [[a[0], a[0]],
      [a[0], a[0]],
      [c[0], a[0]]]],

    [[[b[0], c[0]],
      [b[0], b[0]],
      [a[0], b[0]]],
    
     [[b[0], b[0]],
      [b[0], b[0]],
      [b[0], b[0]]],
    
     [[b[0], a[0]],
      [b[0], b[0]],
      [c[0], b[0]]]],

    [[[c[0], c[0]],
      [c[0], c[0]],
      [a[0], c[0]]],
    
     [[c[0], b[0]],
      [c[0], c[0]],
      [b[0], c[0]]],
    
     [[c[0], a[0]],
      [c[0], c[0]],
      [c[0], c[0]]]],
  ], [
    [[[a[1], c[1]],
      [a[1], a[1]],
      [a[1], a[1]]],
     
     [[a[1], b[1]],
      [a[1], a[1]],
      [b[1], a[1]]],
     
     [[a[1], a[1]],
      [a[1], a[1]],
      [c[1], a[1]]]],
     
    [[[b[1], c[1]],
      [b[1], b[1]],
      [a[1], b[1]]],
    
     [[b[1], b[1]],
      [b[1], b[1]],
      [b[1], b[1]]],
    
     [[b[1], a[1]],
      [b[1], b[1]],
      [c[1], b[1]]]],

    [[[c[1], c[1]],
      [c[1], c[1]],
      [a[1], c[1]]],
    
     [[c[1], b[1]],
      [c[1], c[1]],
      [b[1], c[1]]],
    
     [[c[1], a[1]],
      [c[1], c[1]],
      [c[1], c[1]]]],
  ]]
  
  symbols               = matrix[0]
  descriptions          = matrix[1]

  row_options = [0, 1, 2]
  col_options = [0, 1, 2]
  arr_options = [0, 1, 2]
  sub_options = [0, 1]

  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample
  cur_sub = sub_options.sample
  
  current_probability = 0.33 * 0.33 * 0.33 * 0.25
  current_label       = symbols[cur_row][cur_col][cur_arr][cur_sub]
  current_description = descriptions[cur_row][cur_col][cur_arr][cur_sub]
  current_information = "'#{current_label}', '#{current_description}'"
  
  File.write("data/statistics/probability/current_probability.txt", "#{current_probability}")
  File.write("data/statistics/label/current_information.txt",            current_information)
  File.write("data/statistics/description/current_description.txt",      current_description)
  File.write("data/statistics/symbol/current_label.txt",                 current_label)
end

##########################################################################################
#                                   Liminal Edge Cases                                   #
##########################################################################################
# Uses liminal or subspatial analyses for finding edge cases. This mitigates issues with #
# the original statistical algorithm being susceptible to the "Oz Factor".               #
##########################################################################################
def liminal_edge_cases(*args)
  a1, a2, b1, b2, c1, c2, d1, d2, e1, e2, f1, f2 = args

  a = [ a1, a2 ]
  b = [ b1, b2 ]
  c = [ c1, c2 ]
  d = [ d1, d2 ]
  e = [ e1, e2 ]
  f = [ f1, f2 ]

  edges_cases = [[
    [ a[0], e[0], b[0], d[0], f[0], c[0] ],
    [ e[0], b[0], d[0], f[0], c[0], a[0] ],
    [ b[0], d[0], f[0], c[0], a[0], e[0] ],
    [ d[0], f[0], c[0], a[0], e[0], b[0] ],
    [ f[0], c[0], a[0], b[0], d[0], e[0] ],
    [ c[0], a[0], e[0], b[0], d[0], f[0] ],
  ], [
    [ a[1], e[1], b[1], d[1], f[1], c[1] ],
    [ e[1], b[1], d[1], f[1], c[1], a[1] ],
    [ b[1], d[1], f[1], c[1], a[1], e[1] ],
    [ d[1], f[1], c[1], a[1], e[1], b[1] ],
    [ f[1], c[1], a[1], b[1], d[1], e[1] ],
    [ c[1], a[1], e[1], b[1], d[1], f[1] ],
  ]]
  
  symbols      = edges_cases[0]
  descriptions = edges_cases[1]

  row_options = [0, 1, 2, 3, 4, 5]
  col_options = [0, 1, 2, 3, 4, 5]
  
  cur_row = row_options.sample
  cur_col = col_options.sample
  
  first_symbol      = symbols[cur_row][cur_col] #[cur_arr]
  first_description = descriptions[cur_row][cur_col] #[cur_arr]

  cur_row = row_options.sample
  cur_col = col_options.sample
  #cur_arr = arr_options.sample
  
  second_symbol      = symbols[cur_row][cur_col] #[cur_arr]
  second_description = descriptions[cur_row][cur_col] #[cur_arr]

  cur_row = row_options.sample
  cur_col = col_options.sample
  #cur_arr = arr_options.sample
  
  third_symbol      = symbols[cur_row][cur_col] #[cur_arr]
  third_description = descriptions[cur_row][cur_col] #[cur_arr]
  
  2.times do
    hyper_statistics(first_symbol,  first_description,
                     second_symbol, second_description,
                     third_symbol,  third_description)
                   
    dynamic_reward_allocation
    
    # system("./bin/ternary/kosan #{current_probability} 0.8 #{current_probability} 0.2 #{current_probability} 0.2 0.8")
  end

  current_probability = File.read("./data/statistics/probability/current_probability.txt").to_f
  current_description = File.read("./data/statistics/description/current_description.txt")
  current_symbol      = File.read("./data/statistics/symbol/current_label.txt")
    
  encrire("#{current_symbol.upcase} #{current_description}")
end

#######################################################################################
#                          Advanced Plot Specific Logistics                           #
#######################################################################################
def generate_bounded_probability
  assumed_percentage = "0."

  alpha = ["c", "d", "e", "f", "g", "a", "b"]
  
  a = alpha.sample
  b = alpha.sample
  c = alpha.sample
  d = alpha.sample
  e = alpha.sample
  f = alpha.sample
  g = alpha.sample
  
  "#{assumed_percentage}#{c}#{d}#{e}#{f}#{g}#{a}#{b}"
end

def convert_to_piano_to_percent(fake_percent)
  # if number is 0.eaaaaf, convert to real percent
  real_percent = fake_percent.tr ".cdefgab", ".0123456"
  real_percent = real_percent.to_f

  real_percent
end

#####################################################################################
#                               Limianl Trifd Parser                                #
#####################################################################################
# This combines the characteristics of standard liminal probability analyses, and   #
# trifid analytics to be able to see between the datapoints that are explicitely    #
# stated in a conventional dataset. It also mitigates issues related to the Oz      #
# factor by making it resilient under environmental anomlaies.                      #
#####################################################################################
def liminal_parser(s1, s2, n1, n2, a1, a2,
                   d1, d2, f1, f2, o1, o2,
                   r1, r2, u1, u2, t1, t2,
                   e1, e2, b1, b2, c1, c2,
                   g1, g2, h1, h2, m1, m2,
                   p1, p2, q1, q2, v1, v2,
                   w1, w2,         x1, x2)
                                   
  s  = [s1, s2]; n  = [n1, n2]; a  = [a1, a2];
  d  = [d1, d2]; f  = [f1, f2]; o  = [o1, o2];
  r  = [r1, r2]; u  = [u1, u2]; t  = [t1, t2];
  e  = [e1, e2]; b  = [b1, b2]; c  = [c1, c2];
  g  = [g1, g2]; h  = [h1, h2]; m  = [m1, m2];
  pu = [p1, p2]; q  = [q1, q2]; v  = [v1, v2];
  w  = [w1, w2]; x  = [x1, x2]

  symbols = [[
    [[s[0], r[0]], [n[0], o[0]], [a[0], f[0]]], [[ e[0], v[0]], [b[0], q[0]], [c[0], pu[0]]], [[w[0], t[0]], [x[0], u[0]], [s[0], r[0]]],
    [[d[0], d[0]], [f[0], a[0]], [o[0], n[0]]], [[ g[0], g[0]], [h[0], h[0]], [m[0],  m[0]]], [[n[0], o[0]], [a[0], f[0]], [d[0], d[0]]],
    [[r[0], s[0]], [u[0], x[0]], [t[0], w[0]]], [[pu[0], e[0]], [q[0], b[0]], [v[0],  c[0]]], [[f[0], a[0]], [o[0], n[0]], [r[0], s[0]]],
  ], [
    [[w[0], t[0]], [x[0], u[0]], [s[0], r[0]]], [[s[0], r[0]], [n[0], o[0]], [a[0], f[0]]], [[ e[0], v[0]], [b[0], q[0]], [c[0], pu[0]]],
    [[n[0], o[0]], [a[0], f[0]], [d[0], d[0]]], [[d[0], d[0]], [f[0], a[0]], [o[0], n[0]]], [[ g[0], g[0]], [h[0], h[0]], [m[0],  m[0]]],
    [[f[0], a[0]], [o[0], n[0]], [r[0], s[0]]], [[r[0], s[0]], [u[0], x[0]], [t[0], w[0]]], [[pu[0], e[0]], [q[0], b[0]], [v[0],  c[0]]],
  ], [
    [[ e[0], v[0]], [b[0], q[0]], [c[0], pu[0]]], [[w[0], t[0]], [x[0], u[0]], [s[0], r[0]]], [[s[0], r[0]], [n[0], o[0]], [a[0], f[0]]],
    [[ g[0], g[0]], [h[0], h[0]], [m[0],  m[0]]], [[n[0], o[0]], [a[0], f[0]], [d[0], d[0]]], [[d[0], d[0]], [f[0], a[0]], [o[0], n[0]]],
    [[pu[0], e[0]], [q[0], b[0]], [v[0],  c[0]]], [[f[0], a[0]], [o[0], n[0]], [r[0], s[0]]], [[r[0], s[0]], [u[0], x[0]], [t[0], w[0]]],
  ]]
  
  descriptions = [[
    [[s[1], r[1]], [n[1], o[1]], [a[1], f[1]]], [[ e[1], v[1]], [b[1], q[1]], [c[1], pu[1]]], [[w[1], t[1]], [x[1], u[1]], [s[1], r[1]]],
    [[d[1], d[1]], [f[1], a[1]], [o[1], n[1]]], [[ g[1], g[1]], [h[1], h[1]], [m[1],  m[1]]], [[n[1], o[1]], [a[1], f[1]], [d[1], d[1]]],
    [[r[1], s[1]], [u[1], x[1]], [t[1], w[1]]], [[pu[1], e[1]], [q[1], b[1]], [v[1],  c[1]]], [[f[1], a[1]], [o[1], n[1]], [r[1], s[1]]],
  ], [
    [[w[1], t[1]], [x[1], u[1]], [s[1], r[1]]], [[s[1], r[1]], [n[1], o[1]], [a[1], f[1]]], [[ e[1], v[1]], [b[1], q[1]], [c[1], pu[1]]],
    [[n[1], o[1]], [a[1], f[1]], [d[1], d[1]]], [[d[1], d[1]], [f[1], a[1]], [o[1], n[1]]], [[ g[1], g[1]], [h[1], h[1]], [m[1],  m[1]]],
    [[f[1], a[1]], [o[1], n[1]], [r[1], s[1]]], [[r[1], s[1]], [u[1], x[1]], [t[1], w[1]]], [[pu[1], e[1]], [q[1], b[1]], [v[1],  c[1]]],
  ], [
    [[ e[1], v[1]], [b[1], q[1]], [c[1], pu[1]]], [[w[1], t[1]], [x[1], u[1]], [s[1], r[1]]], [[s[1], r[1]], [n[1], o[1]], [a[1], f[1]]],
    [[ g[1], g[1]], [h[1], h[1]], [m[1],  m[1]]], [[n[1], o[1]], [a[1], f[1]], [d[1], d[1]]], [[d[1], d[1]], [f[1], a[1]], [o[1], n[1]]],
    [[pu[1], e[1]], [q[1], b[1]], [v[1],  c[1]]], [[f[1], a[1]], [o[1], n[1]], [r[1], s[1]]], [[r[1], s[1]], [u[1], x[1]], [t[1], w[1]]],
  ]]
  
  row_options = [0, 1, 2]
  col_options = [0, 1, 2]
  arr_options = [0, 1, 2]
  lim_options = [0, 1]
  
  ## Selects the current row
  cur_row = row_options.sample
  
  ## Selects the current collumn
  cur_col = col_options.sample

  ## Selects the current array index
  cur_arr = arr_options.sample
  
  ## Selects one of two possible states for any given index.
  cur_lim = lim_options.sample
  
  current_symbol      = symbols[cur_row][cur_arr][cur_col][cur_lim]
  current_description = descriptions[cur_row][cur_arr][cur_col][cur_lim]
  current_probability = 0.33 * -0.33 * 0.33
  current_information = "#{current_symbol}, '#{current_description}'"
  
  File.write("data/statistics/probability/current_probability.txt", "#{current_probability}")
  File.write("data/statistics/label/current_information.txt",            current_information)
  File.write("data/statistics/description/current_description.txt",      current_description)
  File.write("data/statistics/symbol/current_label.txt",                 current_symbol)
end

#####################################################################################
#                               Night Walker Algorithm                              #
#####################################################################################
# This is designed to monitor and analyze patterns in information as if one were    #
# trying to blend in with "night walkers" whom take jobs no other types of people   #
# will take. In Uploaded Fairy, the connation is jobs like Le Famille Guillotine,   #
# other other types of morbid professions.                                          #
#                                                                                   #
# Of my machine learning software, this is the only one made explicitely for the    #
# purpose of monitoring a specific family in my alternate history timeline for my   #
# science fiction, such as monitoring the gap between their daywalker and night     #
# walker activities.                                                                #
#####################################################################################
def nuitmarcheuse(n1, n2, i1, i2, g1, g2,
                  h1, h2, t1, t2, w1, w2,
                  a1, a2, l1, l2, k1, k2,
                  e1, e2, r1, r2, b1, b2,
                  c1, c2, d1, d2, f1, f2,
                  j1, j2, m1, m2, o1, o2,
                  p1, p2, q1, q2, s1, s2,
                  u1, u2,         v1, v2) # Lines 37, 41, 44, 49, 53

  n = [n1, n2]
  i = [i1, i2]
  g = [g1, g2]
  h = [h1, h2]
  t = [t1, t2]
  w = [w1, w2]
  a = [a1, a2]
  l = [l1, l2]
  k = [k1, k2]
  e = [e1, e2]
  r = [r1, r2]
  b = [b1, b2]
  c = [c1, c2]
  d = [d1, d2]
  f = [f1, f2]
  j = [j1, j2]
  m = [m1, m2]
  o = [o1, o2]
  p = [p1, p2]
  q = [q1, q2]
  s = [s1, s2]
  u = [u1, u2]
  v = [v1, v2]
  
  nightwalker_symbols = [[
    [n[0], i[0], g[0]], [e[0], r[0], a[0]], [j[0], k[0], m[0]],
    [h[0], t[0], w[0]], [b[0], c[0], d[0]], [o[0], p[0], q[0]],
    [a[0], l[0], k[0]], [e[0], f[0], g[0]], [s[0], u[0], v[0]],
  ], [
    [j[0], k[0], m[0]], [n[0], i[0], g[0]], [e[0], r[0], a[0]],
    [o[0], p[0], q[0]], [h[0], t[0], w[0]], [b[0], c[0], d[0]],
    [s[0], u[0], v[0]], [a[0], l[0], k[0]], [e[0], f[0], g[0]],
  ], [
    [e[0], r[0], a[0]], [j[0], k[0], m[0]], [n[0], i[0], g[0]],
    [b[0], c[0], d[0]], [o[0], p[0], q[0]], [h[0], t[0], w[0]],
    [e[0], f[0], g[0]], [s[0], u[0], v[0]], [a[0], l[0], k[0]],
  ]]

  nightwalker_descriptions = [[
    [n[1], i[1], g[1]], [e[1], r[1], a[1]], [j[1], k[1], m[1]],
    [h[1], t[1], w[1]], [b[1], c[1], d[1]], [o[1], p[1], q[1]],
    [a[1], l[1], k[1]], [e[1], f[1], g[1]], [s[1], u[1], v[1]],
  ], [
    [j[1], k[1], m[1]], [n[1], i[1], g[1]], [e[1], r[1], a[1]],
    [o[1], p[1], q[1]], [h[1], t[1], w[1]], [b[1], c[1], d[1]],
    [s[1], u[1], v[1]], [a[1], l[1], k[1]], [e[1], f[1], g[1]],
  ], [
    [e[1], r[1], a[1]], [j[1], k[1], m[1]], [n[1], i[1], g[1]],
    [b[1], c[1], d[1]], [o[1], p[1], q[1]], [h[1], t[1], w[1]],
    [e[1], f[1], g[1]], [s[1], u[1], v[1]], [a[1], l[1], k[1]],
  ]]

  row_options = [0, 1, 2]
  col_options = [0, 1, 2]
  arr_options = [0, 1, 2]
  
  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample
  
  current_symbol      = nightwalker_symbols[cur_row][cur_arr][cur_col]
  current_description = nightwalker_descriptions[cur_row][cur_arr][cur_col]
  current_probability = 0.33 * 0.33 * 0.33
  current_information = "#{current_symbol}, '#{current_description}'"
end

def marcheuse_de_jour(d1, d2, a1, a2, y1, y2,
                      w1, w2, l1, l2, k1, k2,
                      e1, e2, r1, r2, b1, b2,
                      c1, c2, f1, f2, g1, g2,
                      h1, h2, i1, i2, j1, j2,
                      m1, m2, n1, n2, o1, o2,
                      p1, p2, q1, q2, s1, s2,
                      t1, t2, u1, u2, v1, v2,
                      x1, x2)
                      
  d = [ d1, d2 ]; a = [ a1, a2 ]; y = [ y1, y2 ];
  w = [ w1, w2 ]; l = [ l1, l2 ]; k = [ k1, k2 ];
  e = [ e1, e2 ]; r = [ r1, r2 ]; b = [ b1, d2 ];
  c = [ c1, c2 ]; f = [ f1, f2 ]; g = [ g1, g2 ];
  h = [ h1, h2 ]; i = [ i1, o2 ]; j = [ j1, j2 ];
  m = [ m1, m2 ]; n = [ n1, n2 ]; o = [ o1, o2 ];
  p = [ p1, p2 ]; q = [ q1, q2 ]; s = [ s1, s2 ];
  t = [ t1, t2 ]; u = [ u1, u2 ]; v = [ v1, b2 ];
  x = [ x1, x2 ]

  daywalker_symbols = [[
    [d[0], a[0], y[0]], [c[0], f[0], g[0]], [p[0], q[0], s[0]],
    [w[0], l[0], k[0]], [h[0], i[0], j[0]], [t[0], u[0], v[0]],
    [e[0], r[0], b[0]], [m[0], n[0], o[0]], [w[0], x[0], y[0]],
  ], [
    [p[0], q[0], s[0]], [d[0], a[0], y[0]], [c[0], f[0], g[0]],
    [t[0], u[0], v[0]], [w[0], l[0], k[0]], [h[0], i[0], j[0]],
    [w[0], x[0], y[0]], [e[0], r[0], b[0]], [m[0], n[0], o[0]],
  ], [
    [c[0], f[0], g[0]], [p[0], q[0], s[0]], [d[0], a[0], y[0]],
    [h[0], i[0], j[0]], [t[0], u[0], v[0]], [w[0], l[0], k[0]],
    [m[0], n[0], o[0]], [w[0], x[0], y[0]], [e[0], r[0], b[0]],
  ]]
  
  daywalker_descriptions = [[
    [d[1], a[1], y[1]], [c[1], f[1], g[1]], [p[1], q[1], s[1]],
    [w[1], l[1], k[1]], [h[1], i[1], j[1]], [t[1], u[1], v[1]],
    [e[1], r[1], b[1]], [m[1], n[1], o[1]], [w[1], x[1], y[1]],
  ], [
    [p[1], q[1], s[1]], [d[1], a[1], y[1]], [c[1], f[1], g[1]],
    [t[1], u[1], v[1]], [w[1], l[1], k[1]], [h[1], i[1], j[1]],
    [w[1], x[1], y[1]], [e[1], r[1], b[1]], [m[1], n[1], o[1]],
  ], [
    [c[1], f[1], g[1]], [p[1], q[1], s[1]], [d[1], a[1], y[1]],
    [h[1], i[1], j[1]], [t[1], u[1], v[1]], [w[1], l[1], k[1]],
    [m[1], n[1], o[1]], [w[1], x[1], y[1]], [e[1], r[1], b[1]],
  ]]

  row_options = [0, 1, 2]
  col_options = [0, 1, 2]
  arr_options = [0, 1, 2]
  
  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample
  
  current_symbol      = daywalker_symbols[cur_row][cur_arr][cur_col]
  current_description = daywalker_descriptions[cur_row][cur_arr][cur_col]
  current_probability = 0.33 * 0.33 * 0.33
  current_information = "#{current_symbol}, '#{current_description}'"

  File.write("data/statistics/probability/current_probability.txt", "#{current_probability}")
  File.write("data/statistics/label/current_information.txt",       current_information)
end

#####################################################################################
#                                  Devesfukyana                                     #
#####################################################################################
# Derived from the term dream-scanner, is in referenced to a subset of paranormal   #
# detectives that studying subconcious patterns in dissidents in order to see what  #
# actions they will plan next. In context, Nadine was monitored by one that         #
# eventually defected from Tanner.                                                  #
#####################################################################################
def devesfukyana ( d1, d2, e1, e2, v1, v2,
                   s1, s2, f1, f2, u1, u2,
                   k1, k2, y1, y2, a1, a2,
                   n1, n2, b1, b2, c1, c2,
                   g1, g2, h1, h2, i1, i2,
                   j1, j2, m1, m2, o1, o2,
                   p1, p2, q1, q2, t1, t2,
                   w1, w2, x1, x2, z1, z2 )

  d = [ d1, d2 ]; e  = [ e1, e2 ]; v = [ v1, v2 ];
  s = [ s1, s2 ]; f  = [ f1, f2 ]; u = [ u1, u2 ];
  k = [ k1, k2 ]; y  = [ y1, y2 ]; a = [ a1, a2 ];
  n = [ n1, n2 ]; b  = [ b1, b2 ]; c = [ c1, c2 ];
  g = [ g1, g2 ]; h  = [ h1, h2 ]; i = [ i1, i2 ];
  j = [ j1, j2 ]; k  = [ k1, k2 ]; m = [ m1, m2 ];
  o = [ o1, o2 ]; pu = [ p1, p2 ]; q = [ q1, q2 ];
  t = [ t1, t2 ]; w  = [ w1, w2 ]; x = [ x1, x2 ];
  z = [ z1, z2 ]
  
  symbols = [[
    [ d[0], e[0], v[0] ], [ n[0], b[0], c[0] ], [ o[0], pu[0], q[0] ],
    [ s[0], f[0], u[0] ], [ g[0], h[0], i[0] ], [ t[0],  w[0], x[0] ],
    [ k[0], y[0], a[0] ], [ j[0], l[0], m[0] ], [ z[0],  d[0], e[0] ],
  ], [
    [ o[0], pu[0], q[0] ], [ d[0], e[0], v[0] ], [ n[0], b[0], c[0] ],
    [ t[0],  w[0], x[0] ], [ s[0], f[0], u[0] ], [ g[0], h[0], i[0] ],
    [ z[0],  d[0], e[0] ], [ k[0], y[0], a[0] ], [ j[0], l[0], m[0] ],
  ], [
    [ n[0], b[0], c[0] ], [ o[0], pu[0], q[0] ], [ d[0], e[0], v[0] ],
    [ g[0], h[0], i[0] ], [ t[0],  w[0], x[0] ], [ s[0], f[0], u[0] ],
    [ j[0], l[0], m[0] ], [ z[0],  d[0], e[0] ], [ k[0], y[0], a[0] ],
  ]]

  descriptions = [[
    [ d[1], e[1], v[1] ], [ n[1], b[1], c[1] ], [ o[1], pu[1], q[1] ],
    [ s[1], f[1], u[1] ], [ g[1], h[1], i[1] ], [ t[1],  w[1], x[1] ],
    [ k[1], y[1], a[1] ], [ j[1], l[1], m[1] ], [ z[1],  d[1], e[1] ],
  ], [
    [ o[1], p[1], q[1] ], [ d[1], e[1], v[1] ], [ n[1], b[1], c[1] ],
    [ t[1], w[1], x[1] ], [ s[1], f[1], u[1] ], [ g[1], h[1], i[1] ],
    [ z[1], d[1], e[1] ], [ k[1], y[1], a[1] ], [ j[1], l[1], m[1] ],
  ], [
    [ n[1], b[1], c[1] ], [ o[1], p[1], q[1] ], [ d[1], e[1], v[1] ],
    [ g[1], h[1], i[1] ], [ t[1], w[1], x[1] ], [ s[1], f[1], u[1] ],
    [ j[1], l[1], m[1] ], [ z[1], d[1], e[1] ], [ k[1], y[1], a[1] ],
  ]]

  row_options = [0, 1, 2]
  col_options = [0, 1, 2]
  arr_options = [0, 1, 2]
  
  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample
  
  current_symbol      = symbols[cur_row][cur_arr][cur_col]
  current_description = descriptions[cur_row][cur_arr][cur_col]
  current_probability = 0.33 * 0.33 * 0.33
  current_information = "[:#{current_symbol}, '#{current_description}']"
  
  File.write("data/statistics/probability/current_probability.txt", "#{current_probability}")
  File.write("data/statistics/label/current_information.txt",            current_information)
  File.write("data/statistics/description/current_description.txt",      current_description)
  File.write("data/statistics/symbol/current_label.txt",                 current_symbol)
end

#####################################################################################
#                                  Gurasmitene                                      #
#####################################################################################
# Literally "Grass Mittens", which roughly translates to having a green thumb, or   #
# alternatively sleeping in the grass. This charts uses Gurasmittene as a keyword   #
# for a search operation                                                            #
#####################################################################################
def gurasmitene ( g1, g2, u1, u2, r1, r2,
                  a1, a2, s1, s2, m1, m2,
                  i1, i2, t1, t2, e1, e2,
                  b1, b2, c1, c2, d1, d2,
                  f1, f2, h1, h2, j1, j2,
                  n1, n2, k1, k2, p1, p2,
                  q1, q2, v1, v2, x1, x2,
                          z1, z2, o1, o2)

  g = [ g1, g2 ]; u = [ u1, u2 ]; r  = [ r1, r2 ];
  a = [ a1, a2 ]; s = [ s1, s2 ]; m  = [ m1, m2 ];
  i = [ i1, i2 ]; t = [ t1, t2 ]; e  = [ e1, e2 ];
  b = [ b1, b2 ]; c = [ c1, c2 ]; d  = [ d1, d2 ];
  f = [ f1, f2 ]; h = [ h1, h2 ]; j  = [ j1, j2 ];
  n = [ n1, n2 ]; k = [ k1, k2 ]; pu = [ p1, p2 ];
  q = [ q1, q2 ]; v = [ v1, v2 ]; x  = [ x1, x2 ];
                  z = [ z1, z2 ]; o  = [ o1, o2 ];

  symbols = [[
    [ g[0], u[0], r[0] ], [ b[0], c[0],  d[0] ], [ q[0], u[0], v[0] ],
    [ a[0], s[0], m[0] ], [ f[0], h[0],  j[0] ], [ x[0], z[0], o[0] ],
    [ i[0], t[0], e[0] ], [ n[0], k[0], pu[0] ], [ g[0], u[0], r[0] ],
  ], [
    [ q[0], u[0], v[0] ], [ g[0], u[0], r[0] ], [ b[0], c[0],  d[0] ],
    [ x[0], z[0], o[0] ], [ a[0], s[0], m[0] ], [ f[0], h[0],  j[0] ],
    [ g[0], u[0], r[0] ], [ i[0], t[0], e[0] ], [ n[0], k[0], pu[0] ],
  ], [
    [ b[0], c[0],  d[0] ], [ q[0], u[0], v[0] ], [ g[0], u[0], r[0] ],
    [ f[0], h[0],  j[0] ], [ x[0], z[0], o[0] ], [ a[0], s[0], m[0] ],
    [ n[0], k[0], pu[0] ], [ g[0], u[0], r[0] ], [ i[0], t[0], e[0] ],
  ]]

  descriptions = [[
    [ g[1], u[1], r[1] ], [ b[1], c[1],  d[1] ], [ q[1], u[1], v[1] ],
    [ a[1], s[1], m[1] ], [ f[1], h[1],  j[1] ], [ x[1], z[1], o[1] ],
    [ i[1], t[1], e[1] ], [ n[1], k[1], pu[1] ], [ g[1], u[1], r[1] ],
  ], [
    [ q[1], u[1], v[1] ], [ g[1], u[1], r[1] ], [ b[1], c[1],  d[1] ],
    [ x[1], z[1], o[1] ], [ a[1], s[1], m[1] ], [ f[1], h[1],  j[1] ],
    [ g[1], u[1], r[1] ], [ i[1], t[1], e[1] ], [ n[1], k[1], pu[1] ],
  ], [
    [ b[1], c[1],  d[1] ], [ q[1], u[1], v[1] ], [ g[1], u[1], r[1] ],
    [ f[1], h[1],  j[1] ], [ x[1], z[1], o[1] ], [ a[1], s[1], m[1] ],
    [ n[1], k[1], pu[1] ], [ g[1], u[1], r[1] ], [ i[1], t[1], e[1] ],
  ]]
  
  row_options = [0, 1, 2]
  col_options = [0, 1, 2]
  arr_options = [0, 1, 2]
  
  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample
  
  current_symbol      = symbols[cur_row][cur_arr][cur_col]
  current_description = descriptions[cur_row][cur_arr][cur_col]
  current_probability = 0.33 * 0.33 * 0.33
  current_information = "[:#{current_symbol}, '#{current_description}']"
  
  File.write("data/statistics/probability/current_probability.txt", "#{current_probability}")
  File.write("data/statistics/label/current_information.txt",            current_information)
  File.write("data/statistics/description/current_description.txt",      current_description)
  File.write("data/statistics/symbol/current_label.txt",                 current_symbol)
end

#####################################################################################
#                                  Sanadforutese                                    #
#####################################################################################
# Derived from the term for sand fortress, a kind of shanty town or fortress made   #
# out of crashed spaceships.                                                        #
#####################################################################################
def sanadforutese( s1, s2, a1, a2, n1, n2,
                   d1, d2, f1, f2, o1, o2,
                   r1, r2, u1, u2, t1, t2,
                   b1, b2, c1, c2, g1, g2,
                   h1, h2, j1, j2, k1, k2,
                   e1, e2, m1, m2, p1, p2,
                   q1, q2, v1, v2, x1, x2,
                                   z1, z2)
 
  b = [ b1, b2 ]; c  = [ c1, c2 ]; d = [ d1, d2 ];
  f = [ f1, f2 ]; g  = [ g1, g2 ]; h = [ h1, h2 ];
  j = [ j1, j2 ]; k  = [ k1, k2 ]; m = [ m1, m2 ];
  n = [ n1, n2 ]; pu = [ p1, p2 ]; q = [ q1, q2 ];
  r = [ r1, r2 ]; s  = [ s1, s2 ]; t = [ t1, t2 ];
  u = [ u1, u2 ]; v  = [ v1, v2 ]; x = [ x1, x2 ];
  z = [ z1, z2 ]; a  = [ a1, a2 ]; e = [ e1, e2 ];
  o = [ o1, o2 ]

  symbols = [[
    [s[0], a[0], n[0]],  [b[0], c[0],  g[0]],  [q[0], v[0], x[0]],
    [d[0], f[0], o[0]],  [h[0], j[0],  k[0]],  [z[0], s[0], a[0]],
    [r[0], u[0], t[0]],  [e[0], m[0], pu[0]],  [n[0], d[0], f[0]],
  ], [
    [q[0], v[0], x[0]],  [s[0], a[0], n[0]],  [b[0], c[0],  g[0]],
    [z[0], s[0], a[0]],  [d[0], f[0], o[0]],  [h[0], j[0],  k[0]],
    [n[0], d[0], f[0]],  [r[0], u[0], t[0]],  [e[0], m[0], pu[0]],
  ], [
    [b[0], c[0],  g[0]],  [q[0], v[0], x[0]],  [s[0], a[0], n[0]],
    [h[0], j[0],  k[0]],  [z[0], s[0], a[0]],  [d[0], f[0], o[0]],
    [e[0], m[0], pu[0]],  [n[0], d[0], f[0]],  [r[0], u[0], t[0]],
  ]]
  
  descriptions = [[
    [s[1], a[1], n[1]],  [b[1], c[1],  g[1]],  [q[1], v[1], x[0]],
    [d[1], f[1], o[1]],  [h[1], j[1],  k[1]],  [z[1], s[1], a[0]],
    [r[1], u[1], t[1]],  [e[1], m[1], pu[1]],  [d[1], f[1], o[0]],
  ], [
    [q[1], v[1], x[1]],  [s[1], a[1], n[1]],  [b[1], c[1],  g[0]],
    [z[1], s[1], a[1]],  [d[1], f[1], o[1]],  [h[1], j[1],  k[0]],
    [d[1], f[1], o[1]],  [r[1], u[1], t[1]],  [e[1], m[1], pu[0]],
  ], [
    [b[1], c[1],  g[1]],  [q[1], v[1], x[1]],  [s[1], a[1], n[1]],
    [h[1], j[1],  k[1]],  [z[1], s[1], a[1]],  [d[1], f[1], o[1]],
    [e[1], m[1], pu[1]],  [d[1], f[1], o[1]],  [r[1], u[1], t[1]],
  ]]
  
  row_options = [0, 1, 2]
  col_options = [0, 1, 2]
  arr_options = [0, 1, 2]
  
  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample
  
  current_symbol      = symbols[cur_row][cur_arr][cur_col]
  current_description = descriptions[cur_row][cur_arr][cur_col]
  current_probability = 0.33 * -0.33 * 0.33
  current_information = "[:#{current_symbol}, '#{current_description}']"
  
  File.write("data/statistics/probability/current_probability.txt", "#{current_probability}")
  File.write("data/statistics/label/current_information.txt",            current_information)
  File.write("data/statistics/description/current_description.txt",      current_description)
  File.write("data/statistics/symbol/current_label.txt",                 current_symbol)
end

#####################################################################################
#                                  Seveniripura                                     #
#####################################################################################
# Souvenir En Ripurei - Playing the epilogue of a "side character" through the path #
# of their own memories.                                                            #
#                                                                                   #
# This is done to monitor to see what other people in a person's life might be      #
# important, even if they don't necessarily acknowledge an explicit relationship.   #
#####################################################################################
# You need fifty datapoints in order to train this algorithm.
def suveniripura(s1, s2, u1, u2, v1, v2,
                 e1, e2, n1, n2, i1, i2,
                 r1, r2, p1, p2, a1, a2,
                 b1, b2, c1, c2, d1, d2,
                 f1, f2, g1, g2, h1, h2,
                 j1, j2, k1, k2, m1, m2,
                 o1, o2, q1, q2, t1, t2,
                 w1, w2, x1, x2, y1, y2,
                 z1, z2)

  s = [ s1, s2 ]; u  = [ u1, u2 ]; v = [ v1, v2 ];
  e = [ e1, e2 ]; n  = [ n1, n2 ]; i = [ i1, i2 ];
  r = [ r1, r2 ]; pu = [ p1, p2 ]; a = [ a1, a2 ];
  b = [ b1, b2 ]; c  = [ c1, c2 ]; d = [ d1, d2 ];
  f = [ f1, f2 ]; g  = [ g1, g2 ]; h = [ h1, h2 ];
  j = [ j1, j2 ]; k  = [ k1, k2 ]; m = [ m1, m2 ];
  o = [ o1, o2 ]; q  = [ q1, q2 ]; t = [ t1, t2 ];
  w = [ w1, w2 ]; x  = [ x1, x2 ]; y = [ y1, y2 ];
  z = [ z1, z2 ]

  symbols = [[
    [ s[0],  u[0], v[0] ], [ b[0], c[0], d[0] ], [ o[0], q[0], t[0] ],
    [ e[0],  n[0], i[0] ], [ f[0], g[0], h[0] ], [ w[0], x[0], y[0] ],
    [ r[0], pu[0], a[0] ], [ j[0], k[0], m[0] ], [ z[0], s[0], u[0] ],
  ], [
    [ o[0], q[0], t[0] ], [ s[0],  u[0], v[0] ], [ b[0], c[0], d[0] ],
    [ w[0], x[0], y[0] ], [ e[0],  n[0], i[0] ], [ f[0], g[0], h[0] ],
    [ z[0], s[0], u[0] ], [ r[0], pu[0], a[0] ], [ j[0], k[0], m[0] ],
  ], [
    [ b[0], c[0], d[0] ], [ o[0], q[0], t[0] ], [ s[0],  u[0], v[0] ],
    [ f[0], g[0], h[0] ], [ w[0], x[0], y[0] ], [ e[0],  n[0], i[0] ],
    [ j[0], k[0], m[0] ], [ z[0], s[0], u[0] ], [ r[0], pu[0], a[0] ],
  ]]
  
  descriptions = [[
    [ s[1],  u[1], v[1] ], [ b[1], c[1], d[1] ], [ o[1], q[1], t[1] ],
    [ e[1],  n[1], i[1] ], [ f[1], g[1], h[1] ], [ w[1], x[1], y[1] ],
    [ r[1], pu[1], a[1] ], [ j[1], k[1], m[1] ], [ z[1], s[1], u[1] ],
  ], [
    [ o[1], q[1], t[1] ], [ s[1],  u[1], v[1] ], [ b[1], c[1], d[1] ],
    [ w[1], x[1], y[1] ], [ e[1],  n[1], i[1] ], [ f[1], g[1], h[1] ],
    [ z[1], s[1], u[1] ], [ r[1], pu[1], a[1] ], [ j[1], k[1], m[1] ],
  ], [
    [ b[1], c[1], d[1] ], [ o[1], q[1], t[1] ], [ s[1],  u[1], v[1] ],
    [ f[1], g[1], h[1] ], [ w[1], x[1], y[1] ], [ e[1],  n[1], i[1] ],
    [ j[1], k[1], m[1] ], [ z[1], s[1], u[1] ], [ r[1], pu[1], a[1] ],
  ]]
  
  row_options = [0, 1, 2]
  col_options = [0, 1, 2]
  arr_options = [0, 1, 2]
  
  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample
  
  current_symbol      = symbols[cur_row][cur_arr][cur_col]
  current_description = descriptions[cur_row][cur_arr][cur_col]
  current_probability = 0.33 * 0.33 * 0.33
  current_information = "[:#{current_symbol}, '#{current_description}']"
  
  File.write("data/statistics/probability/current_probability.txt", "#{current_probability}")
  File.write("data/statistics/label/current_information.txt",            current_information)
  File.write("data/statistics/description/current_description.txt",      current_description)
  File.write("data/statistics/symbol/current_label.txt",                 current_symbol)
end

#######################################################################################
#                                      Awasunu                                        #
#######################################################################################
# This handles basic string generation for the scripting language.                    #
#######################################################################################
macro define_method(name, content)
  def {{name}}
    {{content}}
  end
end

define_method viola, system("clear")

define_method ast(label, value), [ label, value ]
define_method       atom(value), ast(value, "#{value}")

define_method   encrire(input), puts input
define_method encrireln(input), print input

## Name of interactive terminal.
define_method documentation(title, description), puts "#{title} #{description}"

def sangehommage(prompt)
  print "#{prompt} "; read_line.chomp # gets.not_nil!.chomp
end

def sangehommage_single_input(prompt)
  print "#{prompt} "; gets.not_nil!.chomp.split(" ")
end


def parle_merci(prompt, output)
  print "#{prompt} "; puts output
end

define_method objet(mot_genre, mot_specifique), "#{mot_genre} #{mot_specifique} "
define_method                  subjet(pronoun),                     "#{pronoun} "
define_method                     verb(action),                      "#{action}."

define_method osv(o, s, v), "#{o} #{s} #{v}"
define_method sov(s, o, v), "#{s} #{o} #{v}"

define_method expression(phrase_one, phrase_two), encrire(%Q(["#{phrase_one}", "#{phrase_two}"]\n))

define_method parle_grammaire(v, o, s), puts "['#{v}', '#{o}','#{s}']"
define_method nihongotupelo(v, o, s), puts "['#{v}', '#{o}', '#{s}']"

## Grammar
define_method ne(first_noun, second_noun), encrireln("Ne #{first_noun} ou #{second_noun}, ")
define_method            mais(third_noun), encrireln("mais c'est #{third_noun}.")

define_method         cette(noun, adjective), "Cette #{noun} est #{adjective}."
define_method      maisette(noun, adjective), "Maisette #{noun} est #{adjective}."
define_method  sinon(noun, adj1, adj2, adj3), "Sinon #{noun} n'est #{adj1} ou #{adj2}, mais c'est #{adj3}."

def ouvert(a, b, c, d, e, g)
  File.open(a, "a") { |f|
    f.puts b
  }

  File.open(c, "a") { |f|
    f.puts d
  }

  File.open(e, "a") { |f|
    f.puts g
  }
end

def ouvert_tr(a1, a2,
              b1, b2,
              c1, c2)

  a = [a1, a2]
  b = [b1, b2]
  c = [c1, c2]

  File.open(a[0], "w") { |f|
    f.print a[1]
  }

  File.open(b[0], "w") { |f|
    f.print b[1]
  }

  File.open(c[0], "w") { |f|
    f.print c[1]
  }
end

def assign_parallel(a, b, c, d, e, f, g, h)
  ## That
  that = cette(a, b)

  ## But That
  but_that = maisette(c, d)

  ## Otherwise
  otherwise = sinon(e, f, g, h)

  ## Exclusive Otherwise
  ouvert("data/cette/cette_inventory.txt",            that,       
         "data/maisette/maisette_inventory.txt",  but_that,
         "data/sinon/sinon_inventory.txt",       otherwise)
end

def corpus_de_livretude(object, subject, verb)
  content = <<-LIVRETRUDE
  word_orders = [
    [[#{verb},   #{object}, #{subjet}],
     [#{objet},  #{subjet},   #{verb}],
     [#{subjet}, #{object}, #{object}]],

    [[#{subjet}, #{object}, #{object}],
     [#{verb},   #{object}, #{subjet}],
     [#{objet},  #{subjet},   #{verb}]],

    [[#{objet},  #{subjet},   #{verb}],
     [#{subjet}, #{object}, #{object}],
     [#{verb},   #{object}, #{subjet}]],
  ]
  
  row_options = [0, 1, 2]
  col_options = [0, 1, 2]
  arr_options = [0, 1, 2]
  
  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample
  
  random_word = word_orders[cur_row][cur_col][cur_arr]
  
  print " : "
  puts random_word
  LIVRETRUDE

  File.open("msrc/corpus_de_livretrude.cr", "w") { |f|
    f.puts content
  }
end

################################################################################################
#                                Conlang Specific Functionality                                #
################################################################################################
define_method      yumemoire(agent, location), "#{agent} has been transported to #{location}."
define_method    posedonokitano(agent, enemy), "#{agent} utilisent le posedonokitano et coupe le #{enemy}."
define_method sanadforutese(sender, reciever), "#{sender} encrivant un lettre pour #{reciever}."

## Describes whether something is haunted, and whether it concentrates yokai.
define_method    yokenozen(agent, location), "#{agent} est en #{location}, c'est yokenozen."
define_method hauntecabine(location, hante),  "#{location} est hante par #{hante}."

### Dialectical differences ( aka aliases )

# Climb hidden latter into cobblestone basement.
define_method entrerokku(agent, entrance, basement), "#{agent} entreroche dans #{basement}."

#### Ninhongo Parlez-Vous
define_method seibetsu(word_class), "#{word_class}"
define_method   ejento(agent_name), "#{agent_name}"
define_method  keiyoshi(adjective),  "#{adjective}"
define_method      shudai(subject),    "#{subject}"
define_method        doshi(action),     "#{action}"
define_method      fukishi(adverb),     "#{adverb}"

define_method nihongo(arg1, arg2, arg3, arg4, arg5, arg6), "#{arg1} #{arg2} #{arg3} #{arg4} #{arg5} #{arg6}"

################################################################################################
#                                  Weaponry And Cursed Items                                   #
################################################################################################
# This defines the DSL for giving recipients cursed items, such as when they reach specific    #
# locations in the Roguelike.                                                                  #
#                                                                                              #
# Traditionally weapon, lamp, and knob smith were considered unclean professions, usually done #
# as a public service when released from colonial prisons. Lamps in particular were the least  #
# clean do them being crafted large enough to function as solitary confinement. This meant     #
# that being able to control the power of a lamp carried connations that don't typically exist #
# in either Japanese or French culture.                                                        #
#                                                                                              #
# Do to the types of animals picked for making soap, more generally the connation of being     #
# washed with that rather than herbal soap, meant the term soap itself being a perjorative for #
# those obsessed more by appearances than being authentic. That's not to say people didn't     #
# clean, but that some soaps were seen as marked with blood.                                   #
################################################################################################
# Cursed weapon smith
define_method kurosumisu(cursed_weapon, recipient),    "#{recipient} avoir un #{cursed_weapon} par anu kurosumisu."

# Cursed lamp smith
define_method coperasumisu(cursed_lamp, recipient),    "#{recipient} avoir un #{cursed_lamp} par anu coperasumisu."

# Cursed knob smith
define_method burasusumisu(crafted_knob, recpipient), "#{recipient} avoir un #{crafted_knob} par anu burasusumisu."

## Soap From Meat, ala "Ivory Soap"
define_method vanedesopu(cursed_meat, recipient),        "#{recipient} avoir un #{cursed_meat} par anu vanedesopu."

## Soap from Herbs "Herbal Soap"
define_method erobalisusopa(cursed_herb, recipient),  "#{recipient} avoir un #{cursed_herb} par ana erobalisusopa."

## Soap from books "Whitewashed books"
define_method iverisopa(cursed_book, recipient),          "#{recipient} avoir un #{cursed_book} par ana iverisopa."

################################################################################################
#                                        French Actions                                        #
################################################################################################
define_method    mange(a, b),    "Mange un #{a} en #{b}."
define_method    coupe(a, b),    "Coupe un #{a} en #{b}."
define_method   cuicre(a, b),   "Cuicre un #{a} en #{b}."
define_method baguette(a, b), "Baguette un #{a} en #{b}."

define_method guillotine(verb, subject),       "Guillotine #{verb} #{subject}."
define_method ax_head(verb, subject),    "Tete Du Crescent #{verb} #{subject}."
define_method roboparle(verb, subject),           "Le robo #{verb} #{subject}."

define_method   parle_a_robo(object, subject, verb, your_name), "#{your_name}: #{subject} #{verb} #{object}"

################################################################################################
#                                         Dream Logic                                          #
################################################################################################
# These are functions specifically in reference to dream patterns I've had when studying my    #
# my own subconscious. A clever analyst will notice that dream symbols also frequently overlap #
# with folklore symbols. The difference here is that dream symbols are treated as explicit     #
# anomalies in order to assess what the unincorporated shadow is.                              #
################################################################################################
define_method argue_purpose(a, b, c),           %Q(#{a} has elements of #{b}, but #{c} is primarily composed of #{b}.)
define_method basement_ghost(a, b, c),          %Q(#{a} checks on noise in #{b}, and invited to dinner by #{c}. Don't eat #{c}'s food or you'll never leave #{b}.)
define_method bedroom_coffee_maker(a, b),       %Q(#{a} is a room in the #{b}.)
define_method deer_attack(a, b),                %Q(Deer #{a} attack specimen #{b} as a unit of multiple deer, before #{b} wakes up.)
define_method explore_bedroom(a),               %Q(#{a} explores the current bedroom.)
define_method goat_ride_salamander(a, b, c, d), %Q(#{a} rides #{b} causing the end of the world, survived by #{c}. #{a} is theorized to eat lifestock, and is unknown whether to target #{d}.)

define_method greenhouse_path(a, b), %Q(#{a} is in the greenhouse of #{b}.)
define_method innocent_hour(a),      %Q(#{a} currently in the hour of innocense, and has tiny horns.)
define_method terror_hour(a),        %Q(#{a} currently in the hour of terror, and has long horns.)
define_method is_haunted?(a, b, c),  %Q(#{a} thinks #{c} is haunted, but not #{b}.)

define_method local_reality_zone(a, b, y1, x1, y2, x2), %Q(#{a} is a local reality zone of #{b}, with #{a} having a local y of #{y1} and x of #{x1}. But #{b} itself only has a y of #{y2} and an x of #{x2}.)
define_method specify_reality_zone(a, b, c),            %Q(#{a}, therefore {b} giving it the #{c} classification.)
define_method non_euclid(a, b),                         %Q(You can fit #{a} inside of #{b} because its exact dimensions aren't defined.)
define_method spot_rainbow_elephant(a, b),              %Q(#{a} is featured in #{b} is a rainbow elephant.)

define_method non_uniform_anomaly(a, b, c, d, e, f), %Q(You can fit #{a} inside of #{b} although top floors y is #{c}, and the top floors x is #{d}. The bottom floor is y of #{e} and x of #{f}.)

define_method plant_evidence(a, b, c), %Q(#{a} murders student #{c}, telling #{b} they framed them for their murder.)
define_method        plant_tree(a, b), %Q(Tree #{a} is planted on plot in #{b}.)

define_method poupee_sassoir(a), %Q(Je avoir s'assoir en le chaise a #{a}.)
define_method   ravenauka(a, b), %Q(#{a} is chased off to the nevermore of #{b} by a demonic raven.)
define_method      sabofensu(a), %Q(Moi ne avoir un avis de: #{a})

define_method squirrel_dog_beetle(a), %Q(#{a} whom looks like a mix of a squirrel, mangi dog, and beetle.)
define_method talk_to_tree(a, b),     %Q(#{a} chats with tree #{b} about its day.)
define_method tree_yard(a, b, c),     %Q(#{a} #{b} #{c})

define_method    try_on_shoes(a, b), %Q(#{a} tries on shoes #{b}.)
define_method     twirl_baton(a, b), %Q(#{a} twirls #{b} like a baton.)
define_method wander_halls(a, b, c), %Q(#{a} wanders from #{b} to #{c}.)

def ghost_upstairs(a, b)
  ghost_states = [
    [[false, false], [false, true]],
    [[true,  false], [true,  true]],
  ]

  row_options = [0, 1]
  col_options = [0, 1]
  arr_options = [0, 1]
  
  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample
  
  current_ghost = ghost_states[cur_row][cur_col][cur_arr]
  
  %Q(#{a} is the middle management of #{b}, that has two floors above #{b}, one below the surface floor: #{current_ghost})
end

################################################################################################
#                                       Ternary Logic                                          #
################################################################################################
def nombres
  bot_name = %Q(BIANCA)

  cette_nombre = Proc(Int32, Int32, String).new { | x, interval |
    x > interval ? %Q(#{bot_name}: #{x} has reached the upper limit in growth.) : %Q(#{bot_name}: #{x} has reached the upper limit in growth.)
  }

  maisette_nombre = Proc(Int32, Int32, String).new { | x, interval |
    x < interval ? %Q(#{bot_name}: #{x} has reached the lower limit in growth.) : %Q(#{bot_name}: #{x} has not reached the limit in growth.)
  }

  sinon_nombre = Proc(Int32, Int32, Int32, String).new { | x, first_interval, second_interval |
    x > first_interval && x < second_interval ? %Q(#{bot_name}: #{x} is floating between growth intervals #{first_interval} and #{second_interval}.) : %Q(#{bot_name}: #{x} is not floating between growth intervals #{first_interval} and #{second_interval}.)
  }

  puts cette_nombre.call(ARGV[0].to_i, ARGV[1].to_i)
  puts maisette_nombre.call(ARGV[2].to_i, ARGV[3].to_i)
  puts sinon_nombre.call(ARGV[4].to_i, ARGV[5].to_i, ARGV[6].to_i)
end

def neg_nombres
  bot_name = %Q(BIANCA)

  necette_nombre = Proc(Int32, Int32, String).new { | x, interval |
    x > interval ? %Q(#{bot_name}: #{x} has reached the upper limit in shrinkage.) : %Q(#{bot_name}: #{x} has reached the upper limit in shrinkage.)
  }

  nemaisette_nombre = Proc(Int32, Int32, String).new { | x, interval |
    x < interval ? %Q(#{bot_name}: #{x} has reached the lower limit in shrinkage.) : %Q(#{bot_name}: #{x} has not reached the lower limit in shrinkage.)
  }

  nesinon_nombre = Proc(Int32, Int32, Int32, String).new { | x, first_interval, second_interval |
    x > first_interval && x < second_interval ? %Q(#{bot_name}: #{x} is floating between shrinkage intervals of #{first_interval} and #{second_interval}.) : %Q(#{bot_name}: #{x} is not floating between shrinkage intervals #{first_interval} and #{second_interval})
  }

  puts necette_nombre.call(ARGV[0].to_i, ARGV[1].to_i)
  puts nemaisette_nombre.call(ARGV[2].to_i, ARGV[3].to_i)
  puts nesinon_nombre.call(ARGV[4].to_i, ARGV[5].to_i, ARGV[6].to_i)
end

def kosan
  bot_name = %Q(#{ARGV[0]}) 

  sore_kosan = Proc(Float64, Float64, String).new { | x, probability |
    x > probability ? %Q(#{bot_name}: #{x} has reached the highest limit in probability.) : %Q(#{bot_name}: #{x} has not reached the highest limit in probability.)
  }

  shikashi_kosan = Proc(Float64, Float64, String).new { | x, probability |
    x < probability ? %Q(#{bot_name}: #{x} has reached the lowest limit in probability.) : %Q(#{bot_name}: #{x} has not reached the lowest limit in probability.)
  }

  matawa_kosan = Proc(Float64, Float64, Float64, String).new { | x, first_probability, second_probability |
    x > first_probability && x < second_probability ? %Q(#{bot_name}: #{x} is floating around medium probability.) : %Q(#{bot_name}: #{x} is not floating around medium probability.)
  }
   
  puts sore_kosan.call(ARGV[1].to_f, ARGV[2].to_f)
  puts shikashi_kosan.call(ARGV[3].to_f, ARGV[4].to_f)
  puts matawa_kosan.call(ARGV[5].to_f, ARGV[6].to_f, ARGV[7].to_f)
end

def nikosan
  bot_name = %Q(#{ARGV[0]})

  nisore_kosan = Proc(Float64, Float64, String).new { | x, probability |
    x > probability ? %Q(#{bot_name}: #{x} has reached the limit in negative probability.) : %Q(#{bot_name}: #{x} has not reached the limit in negative probability.)
  }

  nishikashi_kosan = Proc(Float64, Float64, String).new { | x, probability |
    x < probability ? %Q(#{bot_name}: #{x} has reached the limit in negative probability.) : %Q(#{bot_name}: #{x} has not reached the limit in negative probability.)
  }

  nimatawa_kosan = Proc(Float64, Float64, Float64, String).new { | x, first_probability, second_probability |
    x > first_probability && x < second_probability ? %Q(#{bot_name}: #{x} is floating around medium negative probability.) : %Q(#{bot_name}: #{x} is not floating around medium negative probability.)
  }

  puts nisore_kosan.call(ARGV[1].to_f, ARGV[2].to_f)
  puts nishikashi_kosan.call(ARGV[3].to_f, ARGV[4].to_f)
  puts nimatawa_kosan.call(ARGV[5].to_f, ARGV[6].to_f, ARGV[7].to_f)
end

################################################################################################
################################################################################################
def risuto(search_length, a, b, c)
  search_space = ARGV[0].to_i

  a = ARGV[1]
  b = ARGV[2]
  c = ARGV[3]

  matrix = [
    [[a, a, a],
     [a, a, b],
     [a, a, c]],

    [[b, b, a],
     [b, b, b],
     [b, b, c]],

    [[c, c, c],
     [c, c, c],
     [c, c, c]],
  ]

  row_options = [0, 1, 2]
  col_options = [0, 1, 2]
  arr_options = [0, 1, 2]

  search_space.times do
    cur_row = row_options.sample
    cur_col = col_options.sample
    cur_arr = arr_options.sample
  
    current_item = matrix[cur_row][cur_col][cur_arr]

    encrireln(current_item)
  end
end

################################################################################################
#                                          Obelisk                                             #
################################################################################################
def obelisk(old_data)
  old_graveyard = File.readlines("graveyard/urn.txt").shuffle
  size_limit    = old_graveyard.size.to_i
  index = 0

  File.open("memoricimetiere/urn.txt", "w") { |f|
    f.puts old_data
      
    size_limit.times do
      f.puts old_graveyard[index]
 
      index = index + 1
    end
  }
end

def three_plot_burial(father, mother, child)
  buried_fathers  = File.readlines("graveyard/family/father.txt").uniq.sort
  buried_mothers  = File.readlines("graveyard/family/mother.txt").uniq.sort
  buried_children = File.readlines("graveyard/family/child.txt").uniq.sort

  File.open("graveyard/family/father.txt", "w") { |f|
    f.puts father
    f.puts buried_fathers
  }
  
  File.open("graveyard/family/mother.txt", "w") { |f|
    f.puts mother
    f.puts buried_mothers
  }
  
  File.open("graveyard/family/child.txt", "w") { |f|
    f.puts child
    f.puts buried_children
  }
end

def four_plot_burial(father, mother, brother, sister)
  buried_fathers  = File.readlines("graveyard/family/father.txt").uniq.sort
  buried_mothers  = File.readlines("graveyard/family/mother.txt").uniq.sort
  buried_brothers = File.readlines("graveyard/family/brother.txt").uniq.sort
  buried_sisters  = File.readlines("graveyard/family/sister.txt").uniq.sort

  File.open("graveyard/family/father.txt", "w") { |f|
    f.puts father
    f.puts buried_fathers
  }
  
  File.open("graveyard/family/mother.txt", "w") { |f|
    f.puts mother
    f.puts buried_mothers
  }
  
  File.open("graveyard/family/brother.txt", "w") { |f|
    f.puts brother
    f.puts buried_brothers
  }

  File.open("graveyard/family/sister.txt", "w") { |f|
    f.puts sister
    f.puts buried_sisters
  }
end

def scatter_ashes
  old_graveyard = File.readlines("graveyard/urn.txt").uniq.sort.shuffle
  size_limit    = old_graveyard.size.to_i
  index         = 0
  
  size_limit.times do
    puts old_graveyard[index]
  
    index = index + 1
  end
end

def scatter_three_ashes
  old_fathers  = File.readlines("graveyard/family/father.txt").uniq.sort.shuffle
  old_mothers  = File.readlines("graveyard/family/mother.txt").uniq.sort.shuffle
  old_children = File.readlines("graveyard/family/child.txt").uniq.sort.shuffle

  size_limit    = old_fathers.size.to_i
  index         = 0
  
  ## Scatters fathers ashes in the wind.
  size_limit.times do
    puts old_fathers[index]
  
    index = index + 1
  end
  
  ## Scatters mothers ashes in the wind
  size_limit    = old_mothers.size.to_i
  index         = 0
  
  size_limit.times do
    puts old_mothers[index]
  
    index = index + 1
  end

  ## Scatters childrens ashes in the wind.
  size_limit    = old_children.size.to_i
  index         = 0
  
  size_limit.times do
    puts old_children[index]
  
    index = index + 1
  end
end

def scatter_four_ashes
  old_fathers  = File.readlines("graveyard/family/father.txt").uniq.sort.shuffle
  old_mothers  = File.readlines("graveyard/family/mother.txt").uniq.sort.shuffle
  old_brothers = File.readlines("graveyard/family/brother.txt").uniq.sort
  old_sister   = File.readlines("graveyard/family/sister.txt").uniq.sort

  size_limit    = old_fathers.size.to_i
  index         = 0
  
  ## Scatters fathers ashes in the wind.
  size_limit.times do
    puts old_fathers[index]
  
    index = index + 1
  end
  
  ## Scatters mothers ashes in the wind
  size_limit    = old_mothers.size.to_i
  index         = 0
  
  size_limit.times do
    puts old_mothers[index]
  
    index = index + 1
  end

  ## Scatters brothers ashes in the wind.
  size_limit    = old_brothers.size.to_i
  index         = 0
  
  size_limit.times do
    puts old_brothers[index]
  
    index = index + 1
  end

  ## Scatters sisters ashes in the wind.
  size_limit    = old_sister.size.to_i
  index         = 0
  
  size_limit.times do
    puts old_sister[index]
  
    index = index + 1
  end
end

############################################################################################################
#                                            Maisettemurale                                                #
############################################################################################################
# These commands are for analyzing murals on walls in different parts of the game world.                   #
############################################################################################################
# Analyze painting or mural
define_method muralebunseki(a, b), "Vous avoir analyse #{a} en repos en #{b}."

# Salut and Gaka, or salute the painter, or specifically their painting.
define_method salugaka(a, b), "Vous avoir salute #{a} en photo de #{b}."

def quoi_est_le_poupee(cette, maisette, sinon)
  c = cette("poupee", "victorienne")
  d = maisette("poupee", "barbie")
  e = sinon("poupee", "victorienne", "barbie", "blyth")

  "Est le #{a} avoir un seance en #{b} victorienne? #{c} #{d} #{e}"
end

def est_nom_fausse(a, b, c, d)
  nom_de_plumes = [
    [[a, a, a], [a, a, b], [a, a, c]],
    [[b, b, s], [b, b, b], [b, b, c]],
    [[c, c, a], [c, c, b], [c, c, c]],
  ]
  
  row_options = [0, 1, 2]
  col_options = [0, 1, 2]
  arr_options = [0, 1, 2]
  
  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample
  
  new_name = nom_de_plumes[cur_row][cur_col][cur_arr]

  if new_name == d
    "Checking if that Dolly's name might be fake: #{ner_name}. All thing accorded..."   
  else
    "Checking if that Dolly's name might be fake: #{ner_name}. This name seems to be not legitimate."
  end
end

#################################################################################################################
#                                           Maisette De Relatif                                                 #
#################################################################################################################
# This section for analyzing the relationship between individuals and their relative assessment how likely they #
# are to be estranged from each other, or distance do to some other issue.                                      #
#################################################################################################################
## equation de reduction
define_method reduce_equation(a, b, c), "The equation of #{a}, can be reduced down to #{b} and #{c}."

## which_stopped_talking / qui_a_surpasse_les_conversations
define_method qusurp(a, b), "Do #{a} stop talking before #{b}, or #{b} stop talking before #{a}>"

## which_died_first?
define_method  qui_est_mort_en_premier(a, b), "Do #{a} die before #{b}, or #{b} before #{a}>"

## which relative?
define_method quel_relatif(a), "#{a}"

## is_relative_estranged est relative eloigne
define_method est_relative_eloigne(a, b, c), "Is the relative of #{a} estranged from #{b}?: #{c}"

## is_relative_dead?
define_method est_relativement_mort(a, b, c), "Did #{a} find out that the relative #{b} has died?: #{c}"

## qui a surpassé les conversations / Who surpassed conversations?
define_method qui_a_surpasse_les_conversations(a, b), "Did #{a} stop talking before #{b}, or #{b} stop talking before #{a}?"

## qui est mort en premier
define_method qui_est_mort_en_premier?(a, b), "Did #{a} die before #{b}, or #{b} before #{a}?"

## quel relatif
define_method quel_relatif(a), "#{a}"

## est relative eloigne
define_method est_relative_eloigne?(a, b, c), "Is the relative of #{a} estranged from #{b}?: #{c}"

## est relativement mort? 
define_method est_relativement_mort?(a, b, c), "Did #{a} find out that the relative #{b} has died?: #{c}"

#################################################################################################################
#                                           Scorecard Et Livretude                                              #
#################################################################################################################
def scorecard(rock, paper, scissors)
  max_rock     = 100
  max_paper    = 100
  max_scissors = 100

  final_rock     = rock     / max_rock
  final_paper    = paper    / max_paper
  final_scissors = scissors / max_scissors
  
  score_card = <<-TOTAL
  (require "NeMais")
  
  (defun scorecard (frock fpaper fscissors)
    (setq rock_score         frock)
    (setq paper_score       fpaper)
    (setq scissors_score fscissors)
    
    (princ "\nROCK SCORES\n")
    (princ (sore rock_score       "BIANCA: You achieved the maximum rock score."         "BIANCA: You never achieved a maximum rock score."))
    (princ (shikashi rock_score  " You achieved the medicore paper score."       " You never achieved a medicore paper score."))
    (princ (matawa rock_score " You achieved the minimal scissors score." " You never achieved a minimal scissors score."))

    (princ "\nPAPER SCORES\n")
    (princ (sore paper_score       "BIANCA: You achieved the maximum rock score."         "BIANCA: You never achieved a maximum rock score."))
    (princ (shikashi paper_score  " You achieved the maximum paper score."       " You never achieved a paper score."))
    (princ (matawa paper_score " You achieved the minimal scissors score." " You never achieved a minimal scissors score."))

    (princ "\nSCISSORS SCORES\n")
    (princ (sore scissors_score       "BIANCA: You achieved the maximum rock score."         "BIANCA: You never achieved a maximum rock score."))
    (princ (shikashi scissors_score  " You achieved the medicore paper score."       " You never achieved a medicore paper score."))
    (princ (matawa scissors_score " You achieved the minimal scissors score." " You never achieved a minimal scissors score."))
  )
  
  (scorecard #{final_rock} #{final_paper} #{final_scissors})
  TOTAL
  
  File.open("lisp/scorecard.lisp", "w") { |f|
    f.puts score_card
  }
end

#######################################################################################
#                                        REPL                                         #
#######################################################################################
def awasunu_repl
  file_name = ARGV[0]

  read_file = File.read_lines(file_name)

  total_lines = read_file.size.to_i
  index       = 0

  if total_lines > 0
    total_lines.times do
      current_line = read_file[index]
  
      tokens       = current_line.split(" ")
      total_tokens = tokens.size.to_i
      token_index  = 0
    
      ## The actual tokens you'll be parsing.
      parsed_tokens = [] of String
    
      if total_tokens > 0
        total_tokens.times do
          current_token = tokens[token_index]
 
          parsed_tokens = parsed_tokens.push(current_token)
    
          token_index = token_index + 1
        end
        
        ###################################################################################################
        #                                         Document Parsing                                        #
        ###################################################################################################  
        if    parsed_tokens[0] == "encrire"
          new_output = parsed_tokens[1].tr "_", " "
        
          encrire(new_output)
        elsif parsed_tokens[0] == "encrireln"
          new_output = parsed_tokens[1].tr "_", " "
        
          encrireln(new_output)
        elsif parsed_tokens[0] == "expression"
          expression(osv(parsed_tokens[1], parsed_tokens[2], parsed_tokens[3]),
          sov(parsed_tokens[4], parsed_tokens[5], parsed_tokens[6]))
                          
        elsif parsed_tokens[0] == "parle_grammaire"
          puts parle_grammaire(parsed_tokens[1], parsed_tokens[2], parsed_tokens[3])
        elsif parsed_tokens[0] == "nihongotupelo"
          puts puts nihongotupelo(parsed_tokens[1], parsed_tokens[2], parsed_tokens[3])
        elsif parsed_tokens[0] == "ne_mais"
          print ne(parsed_tokens[1], parsed_tokens[2]); puts mais(parsed_tokens[3])
        elsif parsed_tokens[0] == "cemase"
          puts cette(parsed_tokens[0],    parsed_tokens[1])
          puts maisette(parsed_tokens[2], parsed_tokens[3])
          puts sinon(parsed_tokens[4], parsed_tokens[5], parsed_tokens[6], parsed_tokens[7])
        elsif parsed_tokens[0] == "espace"
          print " "
        else
          puts "Erno: No such function."
        end
      else
        current_token = tokens[token_index]
        
        puts current_token
      end
  
      index = index + 1
    end
  else
    current_line = read_file[index]
  
    puts current_line
  end
end

def parse_lisp(file_name)  
  system("clisp lisp/parsed_map.lisp > scripts/#{file_name}.awa")
  
  system("./awasunu scripts/#{file_name}.awa")
end

def to_lisp(expression_name, active_file)
  file_name = active_file # ARGV[0]

  read_file = File.read_lines(file_name)

  total_lines = read_file.size.to_i

  total_lines = read_file.size.to_i
  index       = 0 

  if total_lines > 0
    total_lines.times do
      current_line = read_file[index]
  
      tokens       = current_line.split(" ")
      total_tokens = tokens.size.to_i
      token_index  = 0
    
      ## The actual tokens you'll be parsing.

      if total_tokens > 0
        parsed_tokens = [] of String

        total_tokens.times do
          current_token = tokens[token_index]
 
          parsed_tokens = parsed_tokens.push(current_token)
    
          token_index = token_index + 1
        
          #puts parsed_tokens
        end

        #puts parsed_tokens
   
        token_limit  = parsed_tokens.size.to_i
        parsed_index = 0

        File.open("lisp/parsed_map.lisp", "a") { |f|
          f.puts "(defun #{expression_name}_#{index} ()"
        }      

        token_limit.times do
          new_atom = atom(parsed_tokens[parsed_index])
        
          File.open("lisp/parsed_map.lisp", "a") { |f|
            f.puts %Q(  (princ "#{new_atom[1]} "))
          }
        
          parsed_index = parsed_index + 1
        end

        File.open("lisp/parsed_map.lisp", "a") { |f|
          f.puts ")\n\n"
        }

        File.open("lisp/parsed_map.lisp", "a") { |f|
          f.puts "(#{expression_name}_#{index})"
          f.puts %Q((princ "
"))
        }
      else
        current_token = tokens[token_index]
        
        puts current_token
      end
     
      index = index + 1
    end
  else
    puts "Erno: No input text"
  end
end

def remove_duplicates(file_name)
  old_graveyard = File.read_lines(file_name).uniq.sort.shuffle
  size_limit    = old_graveyard.size.to_i
  index         = 0
  
  File.open(file_name, "w") { |f|
    size_limit.times do
      f.puts old_graveyard[index]
  
      index = index + 1
    end
  }
  
  # parse_lisp(file_name)
end

#######################################################################################
#                                Awasunu Interpreter                                  #
#######################################################################################
def interpret
  system("clear")

  term_of_art = "Awasunu"
  
  print "#{term_of_art} main on Linux"

  possible_dispatchers = ["encrire",             "encrireln", "expression",
                          "parle_grammaire", "nihongotupelo",    "ne_mais",
                          "cemase"]

  loop do
    dispatcher = sangehommage("\n >>> ")
  
    if    dispatcher == possible_dispatchers[0];
      string = sangehommage(" ...... ")
    
      encrire(string)
    elsif dispatcher == possible_dispatchers[1];
      string = sangehommage(" ...... ")
    
      encrireln(string)
    elsif dispatcher == possible_dispatchers[2];
      parsed_tokens = sangehommage_single_input(" ...... ")

      expression(osv(parsed_tokens[0], parsed_tokens[1], parsed_tokens[2]),
                 sov(parsed_tokens[3], parsed_tokens[4], parsed_tokens[5]))
    elsif dispatcher == possible_dispatchers[3];
      parsed_tokens = sangehommage_single_input(" ...... ")

      parle_grammaire(parsed_tokens[0], parsed_tokens[1], parsed_tokens[2])
    elsif dispatcher == possible_dispatchers[4];
      parsed_tokens = sangehommage_single_input(" ...... ")
    
      nihongotupelo(parsed_tokens[0], parsed_tokens[1], parsed_tokens[2])
    elsif dispatcher == possible_dispatchers[5];
      a, b, c = sangehommage(" ...... "), sangehommage(" ...... "), sangehommage(" ...... ")

      ne(a, b); mais(b)
    elsif dispatcher == possible_dispatchers[6];
      parsed_tokens = sangehommage_single_input(" ...... ")
    
      encrireln(cette(parsed_tokens[0],    parsed_tokens[1]))
      encrireln(maisette(parsed_tokens[2], parsed_tokens[3]))
      encrireln(sinon(parsed_tokens[4], parsed_tokens[5], parsed_tokens[6], parsed_tokens[7]))
    elsif dispatcher == "viola"
      system("clear")
    elsif dispatcher == "exit"
      abort
    else
      puts "Erno: Unknown dispatcher..."
    end
  end
end

#######################################################################################
#                                    Gameloop                                         #
#######################################################################################
def exit_game
  abort
end

def title
  system("clear")

  documentation("\e[38;2;187;127;118mLhacurimosa: Etatunojinege\e[0m", "Welcome to my study of night terrors.")
  
  encrireln("
  ############################################################
  # Type play to play                                        #
  # Type translate to translate conlang                      #
  # Type encyclopedia to research standard topics            #
  # Type neurotoxin index                                    #
  # Type exit to exit simulation                             #
  ############################################################
  ")
  
  input = sangehommage(" >>> ")
  
  if    input == "play"
    stealth_loop
  elsif input == "translate"
  elsif input == "encyclopedia"
  elsif input == "neurotoxin index"
  elsif input == "exit"
    abort
  else
    encrireln("Unrecognized command.")
  end
end

## Detection Status
def detection_status(*args)
  current_probability, current_label = args

  status = sore_float(current_probability > 0.8) do
    encrireln("#{current_label} Vous sont regarder!")
  
    print "What is your name? << "; player_name = read_line.chomp
    print "What is your spider's name? << "; spider_name = read_line.chomp

    enemy_names = ["Sea Gargoyal", "Acid Dragon", "Acid Serpent"]

    gameloop(player_name, spider_name, enemy_names.sample)
  end

  status = shikashi_float(status, current_probability < 0.2) do
    encrireln("#{current_label} Vous ne sont pas regarder!")

    gets.not_nil!.chomp

    stealth_loop
  end

  status = matawa_float(status) do  
    encrireln("#{current_label} Ne oublie pas: Regarder a #{current_probability}.")
  
    gets.not_nil!.chomp
    
    stealth_loop
  end
end

## Player Mechanics
def plure
  sleep 1.5

  puts "Player lured the enemy in their general direction...."

  sleep 1.5
end

def pstun
  sleep 1.5

  puts "Player stunned the enemy...."

  sleep 1.5
end

def ptrap
  sleep 1.5

  system("clear")
  
  puts "Player trapped the enemy...."
  
  puts "You Win"
  
  sleep 1.5
  
  title
end

## Enemy Mechanics
def elure
  sleep 1.5
  
  puts "Enemy lured the player in their general direction...."

  sleep 1.5
end

def estun
  sleep 1.5

  puts "Enemy stunned the player...."

  sleep 1.5
end

def etrap
  sleep 1.5

  system("clear")
  
  puts "Enemy trapped the player...."
  
  print "What is your name? << "; player_name = read_line.chomp
  print "What is your spider's name? << "; spider_name = read_line.chomp

  enemy_names = ["Sea Gargoyal", "Acid Dragon", "Acid Serpent"]

  gameloop(player_name, spider_name, enemy_names.sample)
end

def stealth_loop
  stealth_status = 0.05

  loop do
    system("clear")

    documentation("STEALTH MODE",
                  "\e[38;2;187;127;118m[ lure ] [ stun ] [ trap ]\e[0m")

    liminal_edge_cases( :acid_dragons,     "are dragons that have evolved to live in an acidic environment in the ocean.",
                        :sea_gargoyals,  "are grotesque creatures as statues in the day, and come alive to hunt sailors.",
                        :acid_serpents,                       "are giant snakes that spew acid to destroy their enemies.",
                        :poison_moss,      "is a toxic plant-like entity that needs special clogs in order to walk over.",
                        :treasonous_nun, "are religious figures from the enemy encampment that ally with the main party.",
                        :cthulhu,         "is first elder god of the Cthulhu mythos that destroys mankind when awakened.")

    current_probability = File.read("data/statistics/probability/current_probability.txt").to_f
    current_symbol = File.read("data/statistics/symbol/current_label.txt")
  
    stealth_status = ( stealth_status + current_probability ) / 2

    encrire("You are walking through the passages of ancient temple...")

    encrire("The #{current_symbol.to_s.tr "_", " "} is currently lurking...")

    conditions = {
      "lure" => "stun",
      "stun" => "trap",
      "trap" => "lure",
      
      "find"   =>  "light",
      "light"  => "unlock",
      "unlock" =>   "find",
      
      "title" => "title",
      
      "epee"  =>  "epee",
      "ishi"  =>  "ishi",
      "bache" => "bache",
    }
    
    l = "lure"
    s = "stun"
    t = "trap"
    
    enemy_choices = [
      [[l, l, l],
       [l, l, s],
       [l, l, t]],

      [[s, s, l],
       [s, s, s],
       [s, s, t]],

      [[t, t, l],
       [t, t, s],
       [t, t, t]],
    ]
    
    row_options = [0, 1, 2]
    col_options = [0, 1, 2]
    arr_options = [0, 1, 2]
    
    cur_row = row_options.sample
    cur_col = col_options.sample
    cur_arr = arr_options.sample

    cchoice = enemy_choices[cur_row][cur_col][cur_arr]
    
    # print "< "; puts cchoice
    
    print "> "; choice = read_line.chomp
    
    if    choice == "lure"; "Command accepted"
    elsif choice == "stun"; "Command accepted"
    elsif choice == "trap"; "Command accepted"
    else    
      l = "lure"
      s = "stun"
      t = "trap"
      
      possible_options = [
        [[l, l, l], [l, l, s], [l, l, t]],
        [[s, s, l], [s, s, s], [s, s, t]],
        [[t, t, l], [t, t, s], [t, t, t]],
      ]
    
      row_options = [0, 1, 2]
      col_options = [0, 1, 2]
      arr_options = [0, 1, 2]
      
      cur_row = row_options.sample
      cur_col = col_options.sample
      cur_arr = arr_options.sample
      
      choice = possible_options[cur_row][cur_col][cur_arr]
    end
    
    if    conditions[choice]  == cchoice
      puts "Enemy initiative"

      stealth_status = stealth_status + 0.1

      puts encrire("Your current stealth status is: #{stealth_status}.")

      if    cchoice == "lure"; elure
      elsif cchoice == "stun"; estun
      elsif cchoice == "trap"; etrap
      end
    elsif conditions[cchoice] == choice      
      puts "Player initiative"
    
      stealth_status = stealth_status + 0.1

      encrire("Your current stealth status is: #{stealth_status}.")

      puts detection_status(stealth_status, "Regarder?")
        
      if    choice == "lure"; plure
      elsif choice == "stun"; pstun
      elsif choice == "trap"; ptrap 
      end
    elsif choice              == cchoice
      puts "Stalemate"
    elsif choice == "title"
      title
    else
      puts "Unrecognized input..."
    end
    
    sleep 1.5
  end
end

def gameloop(player_name, spider_name, enemy_name)
  #2.times do
  #  hyper_statistics(:sea_gargoyals, "Sea Gargoyals",
  #                   :acid_dragon,     "Acid Dragon",
  #                   :acid_serpent,   "Acid Serpent")
  #                 
  #  dynamic_mode_switcher
  #end

  liminal_edge_cases( :acid_dragons,     "are dragons that have evolved to live in an acidic environment in the ocean.",
                      :sea_gargoyals,  "are grotesque creatures as statues in the day, and come alive to hunt sailors.",
                      :acid_serpents,                       "are giant snakes that spew acid to destroy their enemies.",
                      :poison_moss,      "is a toxic plant-like entity that needs special clogs in order to walk over.",
                      :treasonous_nun, "are religious figures from the enemy encampment that ally with the main party.",
                      :cthulhu,         "is first elder god of the Cthulhu mythos that destroys mankind when awakened.")
                   
  current_probability = File.read("data/statistics/probability/current_probability.txt").to_f
  
  player_epee  = 0
  player_ishi  = 0
  player_bache = 0
  
  player_level = 15
  spider_level = 15

  base_value = [
    [[400, 400, 400, 400, 400],
     [400, 400, 400, 400, 350],
     [400, 400, 400, 400, 300],
     [400, 400, 400, 400, 250],
     [400, 400, 400, 400, 200]],

    [[350, 350, 350, 350, 400],
     [350, 350, 350, 350, 350],
     [350, 350, 350, 350, 300],
     [350, 350, 350, 350, 250],
     [350, 350, 350, 350, 200]],

    [[300, 300, 300, 300, 400],
     [300, 300, 300, 300, 350],
     [300, 300, 300, 300, 300],
     [300, 300, 300, 300, 250],
     [300, 300, 300, 300, 200]],

    [[250, 250, 250, 250, 400],
     [250, 250, 250, 250, 350],
     [250, 250, 250, 250, 300],
     [250, 250, 250, 250, 250],
     [250, 250, 250, 250, 200]],

    [[200, 200, 200, 200, 400],
     [200, 200, 200, 200, 350],
     [200, 200, 200, 200, 300],
     [200, 200, 200, 200, 250],
     [200, 200, 200, 200, 200]],
  ]

  row_options = [0, 1, 2]
  col_options = [0, 1, 2]
  arr_options = [0, 1, 2]
  
  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample
    
  sea_gargoyals = ( ( base_value[cur_row][cur_col][cur_arr] * current_probability ) * player_level ).to_i

  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample

  acid_dragon   = ( ( base_value[cur_row][cur_col][cur_arr] * current_probability ) * player_level ).to_i

  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample

  acid_serpent  = ( ( base_value[cur_row][cur_col][cur_arr] * current_probability ) * player_level ).to_i
 
  ## Enironmental
  water_acidic        = false

  possible_enemy_level = [3, 5, 7] of Int32

  enemy_level = possible_enemy_level.sample
  
  enemy_hp    = ( 20 * current_probability ) * enemy_level
  enemy_atk   = (  8 * current_probability ) * enemy_level
  enemy_def   = (  4 * current_probability ) * enemy_level

  ## Player Status
  neck_hp             = ( ( enemy_hp  * 0.75 ) * current_probability ) * player_level
  player_atk          = ( ( enemy_atk * 0.75 ) * current_probability ) * player_level
  player_def          = ( ( enemy_def * 0.75 ) * current_probability ) * player_level
  
  coat_durability     = 100 #* player_level
  shirt_durability    = 100 #* player_level
  trouser_durability  = 100 #* player_level
  stocking_durability = 100 #* player_level
  shoe_durability     = 100 #* player_level
  
  player_poison       = false
  player_boat         = false

  spider_hp  = ( 10 * current_probability ) * spider_level
  spider_atk = (  4 * current_probability ) * spider_level
  spider_def = (  2 * current_probability ) * spider_level

  ## Inventory
  antidotes    = 0
  emergency_ax = 0

  line_a = parle_a_robo("tete",  "moi", "coupeon", enemy_name)
  line_b = parle_a_robo("tete",  "moi", "mangeon", enemy_name)                      
  line_c = parle_a_robo("os",   "vous", "mangeon", enemy_name)

  loop do
    viola

    if neck_hp < 1
      viola
    
      puts "\e[38;2;124;58;45m#{player_name}'s head fell off into a conveniently placed whicker basket.\e[0m"
      
      puts <<-BEHEADED
      +--------------------+---
      |                    |---
      -+_   +-----------+  |---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|--___T___--|__|---
      ---|__|-/***T****-|__|---
      ---|__|-|***T***|-|__|---
      ---|__|-|***T***|-|__|---
      ---|__|-**__T___/-|__|---
      ---|__|--_______--|__|---
      ---|__|_|_______|_|__|---
      ---|__| |       | |__|---
      ---|__| |    B  | |__|---
      ---|__|__* B  B |_|__|---
      ---|__|---*_BB_ |-|__|---
      ---|__|--/_____*--|__|---
      ---|__|--*_____/--|__|---
      ---|__|--*_____/--|__|---
      BEHEADED
      
      puts "Game Over"; sleep 3
      
      viola
      
      # exit_game
      
      neck_hp             = 100 #* player_level
      coat_durability     = 100 #* player_level
      shirt_durability    = 100 #* player_level
      trouser_durability  = 100 #* player_level
      stocking_durability = 100 #* player_level
      shoe_durability     = 100 #* player_level
      player_poison       = false
      player_boat         = false
    else
      puts "Bonne travailles!"
    end
    
    if enemy_hp < 1
      system("clear")

      puts <<-BEHEADED
      +--------------------+---
      |                    |---
      -+_   +-----------+  |---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|-----T-----|__|---
      ---|__|--___T___--|__|---
      ---|__|-/***T****-|__|---
      ---|__|-|***T***|-|__|---
      ---|__|-|***T***|-|__|---
      ---|__|-**__T___/-|__|---
      ---|__|--_______--|__|---
      ---|__|_|_______|_|__|---
      ---|__| |       | |__|---
      ---|__| |    B  | |__|---
      ---|__|__* B  B |_|__|---
      ---|__|---*_BB_ |-|__|---
      ---|__|--/_____*--|__|---
      ---|__|--*_____/--|__|---
      ---|__|--*_____/--|__|---
      BEHEADED

      puts "\e[38;2;130;5952;118m#{enemy_name}'s head fell off into a conveniently placed whicker basket.\e[0m"
      
      stealth_loop
    else
      if    sea_gargoyals < 300;
        sea_gargoyals = sea_gargoyals + 10
        
        player_level = player_level + 11
        enemy_level  = enemy_level  + 11
      elsif sea_gargoyals < 225;
        sea_gargoyals = sea_gargoyals + 29

        player_level = player_level + 9
        enemy_level  = enemy_level  + 9
      elsif sea_gargoyals < 169;
        sea_gargoyals = sea_gargoyals + 47

        player_level = player_level + 7
        enemy_level  = enemy_level  + 7
      elsif sea_gargoyals < 127;
        sea_gargoyals = sea_gargoyals + 83

        player_level = player_level + 5
        enemy_level  = enemy_level  + 5
      elsif sea_gargoyals <  96;
        sea_gargoyals = sea_gargoyals + 119

        player_level = player_level + 3
        enemy_level  = enemy_level  + 3
      elsif sea_gargoyals <  72;
        sea_gargoyals = sea_gargoyals + 137

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif sea_gargoyals <  54;
        sea_gargoyals = sea_gargoyals + 155

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif sea_gargoyals <  40;
        sea_gargoyals = sea_gargoyals + 174

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif sea_gargoyals <  30;
        sea_gargoyals = sea_gargoyals + 192

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif sea_gargoyals <  22;
        sea_gargoyals = sea_gargoyals + 228

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif sea_gargoyals <  17;
        sea_gargoyals = sea_gargoyals + 264

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif sea_gargoyals <  13;
        sea_gargoyals = sea_gargoyals + 300

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      else
        puts "Be mindful that there are gargoyals on the open sea."
      end

      if    acid_dragon < 300;
        acid_dragon = acid_dragon + 10
        
        player_level = player_level + 11
        enemy_level  = enemy_level  + 11
      elsif acid_dragon < 225;
        acid_dragon = acid_dragon + 29

        player_level = player_level + 9
        enemy_level  = enemy_level  + 9
      elsif acid_dragon < 169;
        acid_dragon = acid_dragon + 47

        player_level = player_level + 7
        enemy_level  = enemy_level  + 7
      elsif acid_dragon < 127;
        acid_dragon = acid_dragon + 83

        player_level = player_level + 5
        enemy_level  = enemy_level  + 5
      elsif acid_dragon <  96;
        acid_dragon = acid_dragon + 119

        player_level = player_level + 3
        enemy_level  = enemy_level  + 3
      elsif acid_dragon <  72;
        acid_dragon = acid_dragon + 137

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif acid_dragon <  54;
        acid_dragon = acid_dragon + 155

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif acid_dragon <  40;
        acid_dragon = acid_dragon + 174

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif acid_dragon <  30;
        acid_dragon = acid_dragon + 192

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif acid_dragon <  22;
        acid_dragon = acid_dragon + 228

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif acid_dragon <  17;
        acid_dragon = acid_dragon + 264

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif acid_dragon <  13;
        acid_dragon = acid_dragon + 300

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      else
        puts "Be mindful that there are dragons on the acidic riverpasses."
      end

      if    acid_serpent < 300;
        acid_serpent = acid_serpent + 10
        
        player_level = player_level + 11
        enemy_level  = enemy_level  + 11
      elsif acid_serpent < 225;
        acid_serpent = acid_serpent + 29

        player_level = player_level + 9
        enemy_level  = enemy_level  + 9
      elsif acid_serpent < 169;
        acid_serpent = acid_serpent + 47

        player_level = player_level + 7
        enemy_level  = enemy_level  + 7
      elsif acid_serpent < 127;
        acid_serpent = acid_serpent + 83

        player_level = player_level + 5
        enemy_level  = enemy_level  + 5
      elsif acid_serpent <  96;
        acid_serpent = acid_serpent + 119

        player_level = player_level + 3
        enemy_level  = enemy_level  + 3
      elsif acid_serpent <  72;
        acid_serpent = acid_serpent + 137

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif acid_serpent <  54;
        acid_serpent = acid_serpent + 155

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif acid_serpent <  40;
        acid_serpent = acid_serpent + 174

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif acid_serpent <  30;
        acid_serpent = acid_serpent + 192

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif acid_serpent <  22;
        acid_serpent = acid_serpent + 228

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif acid_serpent <  17;
        acid_serpent = acid_serpent + 264

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      elsif acid_serpent <  13;
        acid_serpent = acid_serpent + 300

        player_level = player_level + 1
        enemy_level  = enemy_level  + 1
      else
        puts "Be mindful that there are serpents in the mossy cavern hallways."
      end
    end 

    documentation("\e[38;2;187;127;118mScoreboard\e[0m", "\e[38;2;121;104;118m[ Epee #{player_epee} ] [ Ishi #{player_ishi} ] [ Bache #{player_bache} ]\e[0m")
    documentation("\e[38;2;187;127;118mMonsters Nearby\e[0m", "\e[38;2;121;104;118m[ Sea Gargoyals #{sea_gargoyals} ] [ Acid Dragon #{acid_dragon} ] [ Acid Serpent #{acid_serpent} ]\e[0m")
    
    encrire("\n\e[38;2;123;73;49m#{player_name.upcase} METRICS\e[0m")
    encrire("[ Player Level: #{player_level}]")
    encrire("[ Cou #{neck_hp} ]")
    encrire("[ Manteau #{coat_durability} ]")
    encrire("[ Chemise #{shirt_durability} ]")
    encrire("[ Pantalon #{trouser_durability} ]")
    encrire("[ Bas #{stocking_durability} ]")
    encrire("[ Sabots #{shoe_durability} ]")
    
    encrire("\n\e[38;2;123;73;49m#{spider_name.upcase} METRICS\e[0m")
    encrire("\e[38;2;121;104;118m[ Spider HP #{spider_hp} ] [ Spider Atk #{spider_atk} ] [ Spider Def #{spider_def} ]\e[0m")

    encrire("\n\e[38;2;123;73;49m#{enemy_name.upcase} METRICS\e[0m")
    encrire("\e[38;2;121;104;118m[ Ennemie HP #{enemy_hp} ] [ Ennemie Atk #{enemy_atk} ] [ Ennemie Def #{enemy_def} ]\e[0m")

    dialogue = [line_a, line_b, line_c]

    dialogue_box = <<-DIALOGUE
    
    #{dialogue.sample}
    DIALOGUE

    encrire(dialogue_box)
    
    # awasunu_repl
  
    conditions = {
      "epee"  =>  "ishi",
      "ishi"  => "bache",
      "bache" =>  "epee",
      
      ## Other Tools
      "flashlight" => "flashlight",
      
      "exit"  =>  "exit",
      
      ## In case of error
      "" => "",
    }
  
    choice  = sangehommage("<< ")
  
    en_choices = [
      [["epee", "epee",  "epee"],
       ["epee", "epee",  "ishi"],
       ["epee", "epee", "bache"]],

      [["ishi", "ishi",  "epee"],
       ["ishi", "ishi",  "ishi"],
       ["ishi", "ishi", "bache"]],

      [["bache", "bache",  "epee"],
       ["bache", "bache",  "ishi"],
       ["bache", "bache", "bache"]],
    ]
  
    sp_choices = [
      [["web", "web",  "web"],
       ["web", "web", "bite"],
       ["web", "web", "hiss"]],

      [["bite", "bite",  "web"],
       ["bite", "bite", "bite"],
       ["bite", "bite", "hiss"]],

      [["hiss", "hiss",  "web"],
       ["hiss", "hiss", "bite"],
       ["hiss", "hiss", "hiss"]],
    ]
    
    row_options = [0, 1, 2]
    col_options = [0, 1, 2]
    arr_options = [0, 1, 2]
  
    cur_row = row_options.sample
    cur_col = col_options.sample
    cur_arr = arr_options.sample
  
    pchoice = sp_choices[cur_row][cur_col][cur_arr]
  
    if    pchoice ==  "web";
      encrire("#{spider_name} tissages un web.")
      
      neck_hp = neck_hp + 5
    elsif pchoice == "bite";
      encrire("#{spider_name} calines avec #{player_name}.")
      
      neck_hp = neck_hp + 2
    elsif pchoice == "hiss";
      encrire("#{spider_name} est en sifflement.")
      
      enemy_hp = enemy_hp - 15
    end
    
    cchoice = en_choices[cur_row][cur_col][cur_arr]
  
    puts "[ Player #{choice} /  Enemy #{cchoice} ]"
  
    ## Reasoning about player's choice
    if    choice ==  "epee"; ne("anos ishi", "anos bache"); mais("le epee")
      player_epee = player_epee + 1
    elsif choice ==  "ishi"; ne("le epee", "anos bache"); mais("anos ishi")
      player_ishi = player_ishi + 1
    elsif choice == "bache"; ne("le epee", " anos ishi"); mais("le bache")
      player_bache = player_bache + 1
    # else
      # ne("le player", "le ennui"); mais("le autre")
    end
    
    ## Sanitizes input
    if    choice ==       "epee"; "Command accepted"
    elsif choice ==       "ishi"; "Command accepted"
    elsif choice ==      "bache"; "Command accepted"
    elsif choice == "flashlight"; "Command accepted"
    elsif choice ==       "exit"; "Command accepted"
    else    
      e = "eppe"
      i  = "ishi"
      b  = "bache"
      
      possible_options = [
        [[e, e, e], [e, e, i], [e, e, b]],
        [[i, i, e], [i, i, i], [i, i, b]],
        [[b, b, e], [b, b, i], [b, b, b]],
      ]
    
      row_options = [0, 1, 2]
      col_options = [0, 1, 2]
      arr_options = [0, 1, 2]
      
      cur_row = row_options.sample
      cur_col = col_options.sample
      cur_arr = arr_options.sample
      
      choice = possible_options[cur_row][cur_col][cur_arr]
    end
  
    ## Main Mechanics
    if     conditions[choice] == cchoice
      puts " #{player_name.upcase} Initiative!"; sleep 1.5
      
      possible_monsters = ["sea gargoyals", "acid dragon", "acid serpent"]
      
      current_selection = possible_monsters.sample
      
      if    current_selection == possible_monsters[0]
        enemy_hp = enemy_hp - player_atk
      
        sea_gargoyals = sea_gargoyals - 1
      elsif current_selection == possible_monsters[1]
        enemy_hp = enemy_hp - player_atk
      
        acid_dragon   = acid_dragon   - 1
      elsif current_selection == possible_monsters[2]
        enemy_hp = enemy_hp - player_atk
        
        acid_serpent  = acid_serpent  - 1
      else
        puts "You missed your strike!"
      end      
    elsif conditions[cchoice] == choice
      puts " #{enemy_name.upcase} Initiative!"; sleep 1.5
      
      neck_hp = neck_hp - enemy_atk

      a, b, c, d, e = "Coat", "Shirt", "Pants", "Stockings", "Clogs"
      
      clothing_durability_loss = [
        [[a, a, a, a, a],
         [a, a, a, a, b],
         [a, a, a, a, c],
         [a, a, a, a, d],
         [a, a, a, a, e]],

        [[b, b, b, b, a],
         [b, b, b, b, b],
         [b, b, b, b, c],
         [b, b, b, b, d],
         [b, b, b, b, e]],

        [[c, c, c, c, a],
         [c, c, c, c, b],
         [c, c, c, c, c],
         [c, c, c, c, d],
         [c, c, c, c, e]],

        [[d, d, d, d, a],
         [d, d, d, d, b],
         [d, d, d, d, c],
         [d, d, d, d, d],
         [d, d, d, d, e]],

        [[e, e, e, e, a],
         [e, e, e, e, b],
         [e, e, e, e, c],
         [e, e, e, e, d],
         [e, e, e, e, e]],
      ]

      row_options = [0, 1, 2, 3, 4]
      col_options = [0, 1, 2, 3, 4]
      arr_options = [0, 1, 2, 3, 4]
  
      cur_row = row_options.sample
      cur_col = col_options.sample
      cur_arr = arr_options.sample

      current_clothing = clothing_durability_loss[cur_row][cur_col][cur_arr]
      
      if    current_clothing == a # clothing_durability_loss[0]
        coat_durability = coat_durability - ( enemy_atk / player_def )
      elsif current_clothing == b # clothing_durability_loss[1]
        shirt_durability = shirt_durability - ( enemy_atk / player_def )
      elsif current_clothing == c # clothing_durability_loss[2]
        trouser_durability = trouser_durability - ( enemy_atk / player_def )
      elsif current_clothing == d # clothing_durability_loss[3]
        stocking_durability = stocking_durability - ( enemy_atk / player_def )
      elsif current_clothing == e # clothing_durability_loss[4]
        shoe_durability = shoe_durability - 1
      else
        encrire("#{player_name} narrowly avoided damaging the clothing.")
      end
      
      puts "#{player_name} lost #{enemy_atk} hit points."
    elsif choice == cchoice
      puts " Stalemate"; sleep 1.5
    
    ## Pets
    elsif choice == "flashlight"; sleep 1.5
    
    ## Exit Routines
    elsif choice == "exit"; sleep 1.5
      scorecard(player_epee, player_ishi, player_bache)
      
      system("clisp lisp/scorecard.lisp")
    
      abort
    else
      puts "Unrecognized command..."
    end
  end
end
